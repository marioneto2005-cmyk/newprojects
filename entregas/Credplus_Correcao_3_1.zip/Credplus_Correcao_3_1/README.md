# Credplus 3.1

Correção investigada a partir do XLSB e dos cinco PDFs recebidos. Comece por docs/LEIA-ME.md e consulte docs/DIAGNOSTICO.md e docs/VALIDACAO.md.

O importador é VBA e consome a aba Regras. Os arquivos Python são testes separados de regressão, não uma substituição do importador Excel. Execute `python tests/run_tests.py` com Python 3.10 ou superior para reproduzir as verificações locais; elas não compilam nem executam VBA.

A cópia XLSB preservada contém o código antigo. A base XLSX revisada não contém macros. Instale os componentes completos conforme as instruções e conclua compilação, execução e conversão FileFormat 50 no Excel desktop. Não há XLSB corrigido e compilado produzido neste ambiente Linux.

Os fontes BAS/CLS deste diretório de trabalho estão em UTF-8 para edição. No ZIP entregue eles são convertidos para Windows-1252/CRLF para importação no Editor VBA. TSV e fixtures são UTF-8.
