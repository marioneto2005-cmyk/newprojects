# Diagnóstico da versão recebida

## Inventário e reprodução

Foram recebidos sete anexos: uma solicitação em TXT, `Cotacao_Credplus_Base.xlsb` (136.914 bytes) e cinco PDFs: HDI (2 páginas), Allianz (6), Tokio (5), Yelum (2) e Zurich (2). O arquivo é **XLSB real**, com `xl/workbook.bin`, planilhas binárias e `xl/vbaProject.bin`. Não foram enviados ZIP anterior, BAS/CLS soltos, testes anteriores, capturas de mensagens de erro ou logomarca separada. Não há evidência para afirmar qual mensagem apareceu no Excel do usuário.

O código efetivamente presente está no projeto VBA do XLSB: `Credplus.bas` e `CredplusEventos.cls`, além dos objetos de workbook/planilhas. Os objetos de documento continham atributos, sem eventos implementados. Os componentes foram extraídos para inspeção; não executados.

O estado salvo aponta para Zurich: Dados contém seguradora Zurich e oferta única; Config guarda importação de `zurich-OCR.pdf`; TextoPDF contém o demonstrativo de cálculo 4252345952 e o mesmo segurado/veículo do Zurich anexado. O arquivo OCR externo indicado pelo caminho não foi recebido, mas **seu texto salvo na planilha reproduz os campos ausentes e os valores deslocados**. Assim foi possível reproduzir sem presumir uma versão anterior.

O HDI tem camada textual utilizável pelo Poppler instalado. Os outros quatro PDFs anexados não retornaram conteúdo útil diretamente; o texto inicial tem apenas separadores de página. Foram rasterizados localmente a 220 dpi, processados por Tesseract 5 com português tessdata_fast e reconstruídos como PDF pesquisável para extração `pdftotext -layout -enc UTF-8`. Essa é uma ferramenta de auditoria Linux, não uma execução de NAPS2 Melhor no Windows. As diferenças de OCR são mantidas explícitas.

## Campos com problema: tabela objetiva

A auditoria completa das 46 linhas está em `campos_zurich.csv`. Os principais campos ausentes/incorretos seguem abaixo. Valores foram conferidos no PDF atual; não foram aceitos só por constarem da solicitação anterior.

| Campo | Evidência no PDF/texto | Causa | Correção | Teste realizado |
|---|---|---|---|---|
| Condutor | O nome existe no PDF e em TextoPDF; Sexo está em outra linha no texto salvo | Regex exigia Sexo na mesma linha | Permitir fim de linha ou coluna Sexo | Texto salvo: ausente antes, recuperado após regra; Python |
| Uso profissional/trabalho | Documento afirma uso sem finalidade comercial; pergunta de estacionamento no trabalho tem outra finalidade | Não havia regra para a informação explícita de uso | Transcrever a declaração, sem inferir trabalho pelo estacionamento | Regra no texto Zurich; revisão semântica |
| Faculdade | Resposta informa que veículo não é usado para escola/faculdade, com continuação em outra linha | Campo sem regra Zurich | Capturar pergunta/resposta e continuação específica | Texto salvo e OCR novo |
| Chassi | A imagem é legível; texto salvo tem caracteres extras e O/0 | OCR inválido; validador já o rejeitava | Continuar rejeitando o texto antigo; novo OCR revisável, sem substituições automáticas | Identificador antigo rejeitado; novo comparado visualmente |
| Para-brisa | PDF atual: 285,00; salvo: 615,00 | Camada de texto deslocou valores de várias linhas | Bloquear bloco de vidros quando desestruturado e refazer OCR/revisar | Texto antigo fica ambíguo; OCR local alinhado retorna 285,00 |
| Laterais | PDF atual: 120,00; salvo: 250,00 | Mesmo deslocamento | Mesmo bloqueio do bloco | OCR novo retorna 120,00 |
| Farol convencional | PDF atual: 250,00; salvo: 390,00 | Mesmo deslocamento | Mesmo bloqueio do bloco | OCR novo retorna 250,00 |
| Lanterna LED | PDF atual: 310,00; salvo: 285,00 | Mesmo deslocamento | Mesmo bloqueio do bloco | OCR novo retorna 310,00 |
| Traseiro | PDF atual: 390,00; texto antigo deixa rótulo sem número | Número separado do rótulo | Nunca associar números soltos por ordem | Antigo bloqueado; novo retorna 390,00 |
| Lanterna convencional | PDF atual: 230,00; texto antigo deixa número em linha posterior | Mesmo desalinhamento | Mesmo bloqueio do bloco | Antigo bloqueado; novo retorna 230,00 |
| CPF do condutor | Não há CPF separado identificado no Zurich | Ausência documental | Manter vazio; não copiar CPF do segurado | Ausência mantida |
| APP morte | Só existe APP conjunto de 20.000,00 por passageiro | Ausência de limite separado, não falha de captura | Manter appm vazio e appg conjunto | Teste de não replicação |
| APP invalidez | Mesmo limite conjunto | Ausência de limite separado | Manter appi vazio | Teste de não replicação |
| Placa | Não identificada no Zurich recebido | Ausência documental | Manter não localizado | Inspeção do PDF e extração |
| Combustível | Não há campo explícito separado; FLEX aparece no nome do modelo | Não autoriza completar automaticamente outro campo | Revisão manual | Ausência preservada |
| Zero km | Não identificado explicitamente | Ausência documental | Não inferir pelo ano | Ausência preservada |
| Farol auxiliar | Não identificado no Zurich | Ausência documental | Manter não localizado | Inspeção/extrator |
| Lanterna auxiliar | Não identificada no Zurich | Ausência documental | Manter não localizado | Inspeção/extrator |
| Pagamento | Existem parcelas; meio não é nomeado claramente no Zurich | Decisão não demonstrada no documento | Campo obrigatório para escolha/transcrição conferida | Campo não preenchido por adivinhação; fluxo Excel pendente |
| Observações | Sem observação adicional obrigatória identificada | Campo opcional | Manter vazio ou transcrever dado pertinente | Sem copiar corretora |

Os valores 615/250/390/285 registrados na planilha antiga não podem ser tratados como referências corretas de seus respectivos rótulos. O novo OCR foi confrontado com a imagem do documento atual: a ordem visual permite confirmar 285/120/250/310. A regra nova não contém esses valores como constantes; eles só aparecem nos testes.

## Outros achados e correções

- **Logomarca:** a imagem incorporada é Sicoob Credplus, mas chama-se `Imagem 8`. O exportador procura `LogoCredplus`, portanto poderia bloquear a exportação apesar da imagem visível. A atualização renomeia a imagem existente após confirmação; na base revisada a imagem binária é idêntica à original.
- **Allianz:** há cinco ofertas em dois blocos. O isolamento das colunas foi preservado, com verificação de limite à esquerda da coluna para não capturar prêmio. Foram adicionadas regras de franquia/tipo para o bloco de participação obrigatória. O PDF atual é imagem; no OCR novo o CPF do segurado foi recuperado em **SUAS INFORMAÇÕES**, sem copiar o CPF do condutor. A variante de marcador APP lida por OCR (`APP**+ .`) é aceita apenas no rótulo. A diferença 2.383,99 versus 2.384,00 é mantida como divergência.
- **Tokio:** o título PROPONENTE/CONDUTOR era aceito como cabeçalho de tabela, permitindo que o parser capturasse uma etiqueta no lugar do condutor. O cabeçalho agora exige Proponente e CPF/CNP na mesma linha; o CPF exige estrutura numérica completa. O título PAGAMENTOS desapareceu no OCR local, embora a linha normal `1 ... Sem Juros` estivesse presente: o recorte passou a começar em Débito/ e termina em Ficha. O total vem da coluna Total, sem usar promoção antecipada vencida. O OCR local danificou RCF-V para RCF-Y na cobertura de danos morais; esse campo continua manual, apesar de a imagem mostrar 10.000,00.
- **HDI:** as duas modalidades foram conferidas. A regra de fim de vigência já tinha limite de palavra antes de AS, evitando DAS; foi preservada e testada. Casco determinado permanece numérico (60.750,00) e não é trocado por FIPE. Foram reforçados os limites de token monetário, preservando pontuação após valores nas explicações.
- **Yelum:** os limites de morte/invalidez aparecem na linha anterior ao rótulo específico. As regras existentes atendem ao PDF recebido e foram mantidas/testadas. O CEP de cinco dígitos continua ambíguo. Assistência Superior não recebe quilômetros inventados.
- **Conversão local:** número/data inválido em um campo antes poderia interromper toda a extração. A conversão por campo agora deixa valor vazio e leitura ambígua; datas normalizadas silenciosamente por DateSerial são recusadas.
- **Revisão:** o código anterior concatenava evidências e interrompia ao ultrapassar 32.000 caracteres. O registro completo agora é dividido em células internas de até 30.000 caracteres, sem truncar a assinatura. Inclui dados, fórmulas/valores/formatos relevantes, regras e dimensões. É um registro de consistência para detectar alterações, não assinatura criptográfica.
- **Etiqueta no lugar de chamada:** no exportador antigo, `InvalidarRevisao:` era uma etiqueta VBA, não uma chamada ao procedimento. A exportação bloqueava por divergência, mas a invalidação pretendida não ocorria ali. Agora há chamada explícita separada.
- **Eventos:** antes havia uma classe Application WithEvents dependente da inicialização por Auto_Open. Os eventos de documento estavam vazios. Agora os eventos nativos de ThisWorkbook criam uma instância curta da classe delegada; não dependem de um sink sobrevivendo ao Reset. EnableEvents é capturado antes dos acessos e restaurado nas saídas. O recálculo dos botões após SaveAs tem bloqueio contra salvamento recursivo.
- **Processos:** esperar com stdout/stderr em pipes sem drenar pode causar bloqueio. A execução usa arquivo de log na pasta exclusiva e solicita encerramento da árvore do processo iniciado em timeout/cancelamento. Essa implementação ainda requer teste real no Windows.
- **OCR forçado:** o NAPS2 oficial pode preservar páginas que já têm texto. A rota forçada agora rasteriza uma cópia em TIFF multipágina antes de aplicar OCR. O PDF original nunca é alterado; somente nomes conhecidos dentro da pasta criada pela execução são limpos.
- **Estado transacional:** o array novo é preparado antes de substituir Dados. Cancelamento anterior à gravação preserva os valores. Uma falha de gravação tenta restaurar os snapshots e invalida a revisão; a mensagem não promete restauração perfeita se a própria restauração falhar.
- **Apresentação:** referências de 46 campos foram verificadas; dinheiro zero não é tratado como vazio. O formato de casco aceita número determinado ou texto FIPE. Há medição de texto e limite de tamanho antes de confirmar/exportar; a conferência final do PDF continua necessária.

## Cadeia de investigação e limites

Para o condutor: imagem → texto salvo → regex → grupo → linha Dados → fórmula Cotacao foi possível rastrear o defeito. Para vidros: a imagem é correta, a camada textual salva quebra a tabela, a regex isolada captura números plausíveis errados, e as fórmulas apenas exibem esses valores. A correção ocorre no bloqueio da tabela e no OCR, não em uma fórmula que troque números.

As referências das fórmulas foram inspecionadas numa cópia convertida e verificadas novamente na base revisada. O desenho da apresentação foi renderizado em duas páginas numa prévia **LibreOffice** com as abas internas ocultas apenas na cópia de auditoria. Isso não testa `ExportAsFixedFormat` do Excel, nem valida o arquivo de cliente gerado pelo VBA.

## Fontes dos comandos

- NAPS2 oficial, código-fonte consultado no commit `9d4f0c7f489b99b1aa78aaa7f98be8e8020a703d`: `NAPS2.Lib/Automation/AutomatedScanningOptions.cs` declara `-i`, `-o`, `-n`, `--ocrlang`, `--disableocr`; `--ocrlang` implica habilitar OCR. `NAPS2.Sdk/Pdf/PdfExporter.cs`, CheckIfOcrNeededStep, verifica texto preexistente. `NAPS2.Lib/ImportExport/Images/SaveImagesOperation.cs` suporta TIFF multipágina por padrão.
- Repositório oficial: https://github.com/cyanfish/naps2/tree/9d4f0c7f489b99b1aa78aaa7f98be8e8020a703d
- A documentação web de NAPS2 e Xpdf retornou HTTP 403 neste ambiente. O NAPS2 foi confirmado pelo código oficial; a CLI efetivamente instalada no Windows continua sem teste.
- A ajuda local de Poppler `pdftotext 25.03.0 -h` confirma `-layout`, `-enc UTF-8` e a ordem PDF/arquivo-texto. Não houve execução do Xpdf configurado no Windows, nem promessa de equivalência entre os extratores.

Word não foi reintroduzido: reorganizar tabelas aumenta o risco de confundir LMI/prêmio e colunas. O runtime continua exigindo pdftotext; não foi adicionada outra ferramenta externa obrigatória além de NAPS2 e pdftotext. Tesseract/Poppler Linux foram usados somente na auditoria dos anexos.


## Ajuste confirmado durante a instalacao Windows

A captura enviada pelo usuario mostra `pdftotext version 4.06 [www.xpdfreader.com]` com codigo 99 na consulta `-v`. O executavel foi encontrado e executado; o diagnostico rejeitava indevidamente esse retorno. A excecao agora aceita 0/99 somente na consulta fixa de versao e exige o banner `pdftotext version numero.numero`. Extracao, OCR e demais comandos continuam exigindo codigo zero. Isso nao comprova ainda a extracao de um PDF nem o funcionamento do NAPS2.


## Causa confirmada no diagnostico Windows e correcao de extracao Zurich

O ZIP de diagnostico enviado pelo usuario contem a entrada original (hash identico ao Zurich anexado inicialmente), OCR direto, TIFF, OCR rasterizado e os textos dos modos -layout/-table. NAPS2 8.5.1 executou as etapas com codigo 0. O Xpdf 4.06 tambem retornou 0 nas extracoes. Portanto, neste caso nao houve falha de OCR/processo; o modo -layout reorganiza incorretamente as linhas de texto do bloco de vidros. Repetir o OCR produz a mesma camada e nao resolve esse alinhamento.

O modo -table do MESMO executavel Xpdf preserva as linhas. O COMPARACAO.tsv, gerado pelo proprio VBA no Excel do usuario, confirma para-brisa 285; laterais 120; traseiro 390; farol 250; farol LED 1405; lanterna 230; lanterna LED 310; retrovisor 385. Total 2295,71 e franquia 5942,25 permanecem corretos. Essa evidencia e de execucao real do parser no Excel, embora a integracao final nova ainda dependa de instalar/compilar o novo modulo.

A importacao agora identifica o fornecedor pelo banner -v, confirma a seguradora escolhida e usa -table somente para Zurich com Xpdf. Se houve OCR, a extracao em tabela usa o PDF OCR da mesma execucao. Poppler e as outras seguradoras mantem o modo anterior. A configuracao B12 e a mensagem final informam o modo efetivamente utilizado. A verificacao de texto inalterado do OCR forcado ocorre depois da tentativa de formato de tabela, evitando recusar uma recuperacao possivel so porque o OCR repetiu a mesma leitura.

O chassi permanece errado no texto dos dois modos e e rejeitado pelo validador. Deve ser conferido e transcrito manualmente a partir da imagem original; nenhum caractere foi trocado por suposicao. Placa, combustivel separado e zero km seguem sem evidencia explicita neste documento.
