# Credplus — correção 3.1

O caso Zurich salvo no XLSB foi reproduzido: havia dados presentes que a regra não encontrava e valores de franquias de vidros associados às linhas erradas. Os componentes completos e as regras foram corrigidos. A validação executada neste ambiente é de regras em Python, inspeção dos componentes e da estrutura da planilha. **Não houve compilação nem execução no Excel desktop.**

## Arquivos e escolha da base

- `base/Cotacao_Credplus_ORIGINAL_PRESERVADA.xlsb`: cópia byte a byte do XLSB enviado, incluindo VBA antigo, imagem, botões e dados. É uma base de preservação, **não é o resultado corrigido pronto para uso**.
- `base/Cotacao_Credplus_Revisada.xlsx`: base alternativa sem macros, com as cinco abas, 237 regras, fórmulas e imagem preservada; os dados da importação anterior foram limpos. Foi reconstruída por conversão de uma cópia com LibreOffice e edição OOXML. Não é XLSB e ainda exige instalar os componentes e salvar pelo Excel.
- `src/Credplus.bas`, `CredplusEventos.cls`, `CredplusAtualizacao.bas` e `TestesCredplus.bas`: componentes completos para importar. Na entrega ZIP estão em **Windows-1252, CRLF, sem BOM**, apropriados ao Editor VBA em Windows com idioma português. Confira os acentos após importar.
- `src/ThisWorkbook_codigo.txt`: eventos para colar no objeto EstaPastaDeTrabalho, não em um módulo comum.
- `src/Regras.tsv`: fonte UTF-8 das regras. A macro de atualização carrega seu conteúdo em `Regras!A6:H242`; **a extração continua consumindo a aba Regras**, sem ler o TSV a cada PDF.
- `tests/fixtures`: textos reais de diagnóstico e de OCR local, com os dados pessoais dos exemplos, somente para teste interno. `tests/engine.py` é um modelo de regressão em Python, não o importador usado pelo Excel.
- `docs/DIAGNOSTICO`, `docs/VALIDACAO`, `docs/campos_zurich.csv`, inventário e resultados dos testes: evidências e limitações.

O caminho preferido para preservar integralmente o projeto é atualizar **uma cópia do XLSB original**. A base XLSX revisada é alternativa caso precise começar limpa.

## Instalação no Excel, sem duplicar procedimentos

1. Extraia o ZIP inteiro para uma pasta local. Guarde uma cópia intocada do original. Trabalhe em outra cópia, por exemplo `Cotacao_Credplus_EmAtualizacao.xlsb`.
2. Abra essa cópia no Excel. Durante a substituição, mantenha as macros desabilitadas. Pressione Alt+F11.
3. Em Módulos, remova o módulo antigo `Credplus`. Em Módulos de classe, remova a classe antiga `CredplusEventos`. Não remova as cinco planilhas nem o objeto EstaPastaDeTrabalho. Se estiver usando uma versão com `CredplusAtualizacao` ou `TestesCredplus`, remova a versão antiga desses módulos também. Não mantenha `Credplus1` ou duas cópias dos mesmos procedimentos.
4. Importe os quatro arquivos BAS/CLS da pasta `src`. O nome da classe deve ficar exatamente `CredplusEventos`. Não copie linhas `Attribute VB_Name` manualmente em uma janela de código; use Arquivo > Importar arquivo.
5. Abra o código de **EstaPastaDeTrabalho / ThisWorkbook** e cole o conteúdo de `ThisWorkbook_codigo.txt`. Na versão enviada esse objeto não continha eventos. Se sua cópia tiver outros eventos, incorpore os corpos sem duplicar `Workbook_Open`, `Workbook_Activate`, `Workbook_SheetChange`, `Workbook_BeforeSave` ou `Workbook_AfterSave` ou `Workbook_BeforeClose`.
6. Use Depurar > Compilar VBAProject. Corrija qualquer mensagem antes de prosseguir; não considere a compilação aprovada sem executá-la. O código evita declarações de API específicas de 32/64 bits, mas ambas as arquiteturas continuam sem teste real. Referências quebradas de outros componentes exigem análise no próprio Excel.
7. Salve a cópia mantendo XLSB, feche e reabra. Habilite macros apenas conforme o procedimento autorizado da sua organização. Nenhum script desta entrega altera políticas, Central de Confiabilidade, Registro ou permissões do Office.
8. Execute `AplicarCorrecaoCredplus` com Alt+F8. Selecione o arquivo `src/Regras.tsv` desta entrega e confirme aplicar **na cópia**. A macro preserva os valores de Dados, caminhos, consultor/contato e imagens; troca regras/fórmulas e invalida a revisão. Por isso, **reimporte o PDF**: os valores antigos não são corrigidos por adivinhação.
9. Confirme visualmente a logomarca já existente quando perguntado. A imagem incorporada no arquivo recebido é Sicoob Credplus; o nome antigo `Imagem 8` era diferente de `LogoCredplus`. A atualização identifica a imagem mediante confirmação; não baixa nem substitui a identidade visual.
10. Verifique em Config os caminhos reais de `NAPS2.Console.exe` (B4) e `pdftotext.exe` (B5). Os caminhos recebidos são apenas configurações, não prova de instalação. Mantenha B6=Sim, B7=por, B13 entre 10 e 3600 segundos por processo. No NAPS2, confirme português instalado, modo Melhor e PDF pesquisável.
11. Execute `DiagnosticarFerramentas`. A macro verifica presença e tenta `pdftotext -v` e `NAPS2.Console --help`; não instala programas. O teste com PDF ainda é obrigatório. Um Xpdf instalado deve ser validado por seus próprios resultados: o teste Linux usou Poppler 25.03.0, não o executável Windows.
12. Execute `TestarCredplus` e selecione a pasta `tests/fixtures`. A suíte contém 15 casos para rodar no próprio Excel e grava um novo CSV com os resultados efetivos. Essa suíte **não foi executada aqui** e não substitui o checklist de integração.

## Operação e revisão

1. Use Importar PDF + OCR e selecione somente um PDF. Confirme seguradora e escolha o número da oferta quando houver mais de uma. Cancelar os diálogos não substitui os valores anteriores. A nova matriz de 46 campos é preparada antes da gravação.
2. Para refazer uma camada textual defeituosa, use Reprocessar com OCR e selecione novamente o PDF desejado. Essa rota faz PDF → TIFF multipágina → PDF pesquisável, em pasta temporária exclusiva. Ela evita presumir que NAPS2 refará texto já existente. Sua execução real depende da versão instalada e está pendente de teste no Windows.
3. Revise B6:B51 de Dados, comparando a evidência D com a **imagem original**. Não basta concordar com números plausíveis. Todas as leituras localizadas começam como Revisar. Classifique C como Revisado, Nao contratado, Nao se aplica ou Nao localizado. Valores ambíguos precisam de correção/decisão explícita; campos obrigatórios faltantes bloqueiam a exportação.
4. Digite dinheiro como número e datas como datas reais. CPF/CNPJ, CEP, placa e chassi devem continuar como texto. Não complete o CEP Yelum de cinco dígitos nem corrija chassi trocando caracteres por suposição.
5. O pagamento não é escolhido silenciosamente. Preencha Dados!B50 com a condição efetivamente escolhida e conferida: meio, entrada, quantidade/valor das parcelas, juros e total, conforme existirem no documento. Se o meio não estiver claro, confirme com a seguradora; não invente. A evidência da tabela fica em D50/TextoPDF.
6. Use Confirmar revisão. O código valida os campos, mede o texto para reduzir risco de corte e grava o registro integral em partes de até 30.000 caracteres na coluna D de Config. D4 identifica o registro; D5 em diante são internos e não devem ser editados.
7. Use Gerar PDF cliente. A exportação usa somente `Cotacao!A1:H62`, exige revisão atual e cotação válida, preserva arquivos existentes e salva um novo PDF. Botões ficam fora da impressão. Não use exportação manual da pasta inteira para substituir esse fluxo, pois ela pode incluir abas internas e não passa pelas verificações da macro.
8. Abra o PDF gerado no seu Excel e confira as duas páginas, legibilidade, valores, identificação e ausência de abas internas/corretora intermediária. A medição de layout não substitui essa conferência. Textos longos podem exigir resumo fiel em Dados; o código bloqueia conteúdo excessivo em vez de prometer que sempre caberá em duas páginas.
9. Alterações em Dados/Config relevante/Cotacao/Regras invalidam a revisão. Os eventos agora são do próprio ThisWorkbook e delegam à classe, sem depender de uma variável WithEvents ter sido reinicializada após Reset.

## XLSB verdadeiro

Depois de instalar e compilar, execute `ConverterParaXLSB`, escolha um **nome novo** e deixe o Excel salvar com FileFormat 50 (xlExcel12). Não renomeie a extensão do XLSX. A macro aceita XLSB=50 e XLSM=52 para exportação, mas o formato final solicitado é XLSB.

Feche/reabra o XLSB novo e confirme imagem, fórmulas, módulos, botões e duas páginas. Teste também Salvar como com outro nome; OnAction deve acompanhar o nome atual. O arquivo XLSB final **corrigido, compilado e validado** depende dessas etapas no Excel: ele não foi fabricado neste ambiente Linux.

## Limites e pendências

Os 32 testes Python passaram, mas não validam o VBA nem a instalação Windows. Compilar, executar macros, validar NAPS2/Poppler ou Xpdf, timeout/cancelamento, eventos após Reset e PDF realmente exportado pelo Excel seguem pendentes. Consulte VALIDACAO antes do uso operacional.

Nenhum commit ou arquivo foi enviado ao GitHub durante esta investigação. Os originais anexados foram preservados; os dados pessoais dos testes não foram publicados.


## Atualizacao apos diagnostico executado no seu Windows

Para Zurich com Xpdf, ImportarPDF agora usa automaticamente -table depois da confirmacao da seguradora. A evidencia COMPARACAO.tsv enviada pelo usuario comprova os oito valores de vidros recuperados pelo parser VBA com esse modo. O chassi continua exigindo conferencia manual porque o OCR efetivamente leu caracteres invalidos. Para quem ja instalou todos os componentes, basta substituir Credplus.bas pelo ajuste Zurich/Xpdf, compilar e importar novamente; nao e necessario reaplicar Regras.tsv. O novo fluxo integrado ainda precisa ser executado no Excel do usuario.
