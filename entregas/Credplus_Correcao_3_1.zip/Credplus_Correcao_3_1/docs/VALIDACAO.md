# Validação e testes pendentes

## O que foi executado

| Nível | Resultado | Evidência e limite |
|---|---|---|
| Inventário dos anexos e extração de VBA | Executado | XLSB real, cinco abas e módulos efetivamente incorporados identificados. Originais preservados. |
| Texto nativo dos PDFs | Executado | Poppler 25.03.0 no Linux; HDI extraível, outros quatro sem texto útil diretamente. |
| OCR dos PDFs-imagem | Executado localmente | Tesseract 5/por tessdata_fast, 220 dpi, PDF pesquisável e pdftotext -layout. Não equivale a NAPS2 Melhor. |
| Conferência de imagens dos PDFs de entrada | Executada nos trechos relevantes | Zurich página 1 (rótulos/valores), Allianz página 2 (cinco ofertas), Tokio página 4 (preço normal/pagamentos), Yelum página 1. Documentos de entrada, não PDFs exportados por Excel. |
| Regras de extração em Python | 27 testes PASS, zero FAIL/ERROR/SKIP | Inclui testes de regras e inspeção estática. Arquivos resultados_testes.csv, testes_python.log e resultado_execucao.json registram a execução. Não são testes do motor VBScript nem de VBA. |
| Ofertas/modalidades | 11 avaliadas | Allianz 5, HDI 2, Tokio 2, Zurich 1, Yelum 1, com dados extraídos dos PDFs recebidos. |
| Inspeção estática VBA | Executada, com verificações automatizadas | Estrutura/nomes de procedimentos, grupos de regras, escopo de exportação e proteções de processos. Não é um compilador; não garante ausência de erro de compilação. |
| Base revisada XLSX | Executado | Cinco abas, 46 referências de fórmula, 237 regras, dados anteriores limpos; logo binário idêntico e seis formas de botões preservadas. |
| Preservação do XLSB recebido | Executado | Hash da cópia preservada igual ao original; VBA, planilhas e demais partes mantidas byte a byte. A cópia preservada ainda contém o código antigo. |
| Prévia de layout LibreOffice | Duas páginas observadas em cópia de diagnóstico | Abas internas foram ocultadas somente nessa cópia; não demonstra execução do exportador Excel nem preservação VBA por conversão LibreOffice. |
| Compilação real Excel | NÃO EXECUTADA | Excel desktop indisponível neste ambiente Linux. |
| Execução real de macros | NÃO EXECUTADA | Inclui os 15 casos TestarCredplus fornecidos para rodar no usuário. |
| NAPS2 Windows / Xpdf ou Poppler Windows | NÃO EXECUTADOS | Caminhos, versões, OCR por/Melhor e sintaxe na versão instalada precisam ser confirmados. |
| PDF realmente exportado pelo Excel corrigido | NÃO GERADO NEM CONFERIDO | Deve ser validado depois da instalação, compilação e revisão. |

## Regressões verificadas em Python

- Reprodução do texto Zurich salvo: condutor ausente e associação incorreta de para-brisa/laterais/farol.
- Regra corrigida de condutor e rejeição do bloco Zurich antigo inteiro como ambíguo.
- OCR novo Zurich versus imagem: para-brisa 285,00, laterais 120,00, traseiro 390,00, farol 250,00, LED 1.405,00, lanterna 230,00, lanterna LED 310,00, retrovisor 385,00; total/franquia/LMI mantidos.
- APP conjunto Zurich não replicado em morte/invalidez; código A não inferido como 50%.
- Allianz: cinco totais e LMI corretos por oferta, dois blocos, franquia recuperada, CPF do segurado com evidência própria, diferença de centavo no Exclusivo sinalizada.
- Remoção de LMI Allianz preservando o prêmio: o prêmio não foi usado como LMI, nas cinco ofertas.
- Tokio: preço normal e franquia das duas ofertas, valores de vidros e distinção de oficina; promoção antecipada não usada. Rótulo de morais danificado pelo OCR permanece não localizado.
- HDI: VMR versus determinado, casco numérico da modalidade determinada, vigência 2026–2027, valores em explicações com ponto de fim de frase.
- Yelum: APP multiline, datas, CEP incompleto rejeitado e ausência de quilometragem inventada.
- Números truncados, caracteres inválidos, duplicação de documentos com nomes diferentes, data impossível e identificadores inválidos.
- Uma chamada de extração depois de outra sem reter valores; zero numérico distinto de ausência. Esse teste de modelo não comprova rollback de planilha no Excel.

## Checklist obrigatório no Excel/Windows

Marque somente depois de executar e conferir. Todos os itens abaixo estão **PENDENTES** na entrega.

| Teste | Como executar | Resultado exigido |
|---|---|---|
| Compilar | Depurar > Compilar VBAProject após substituir os quatro componentes e o código de ThisWorkbook | Sem mensagens de compilação ou referências quebradas |
| Arquitetura | Anotar Arquivo > Conta > Sobre o Excel: 32 ou 64 bits e versão/build | Arquitetura registrada; funcionamento validado na instalação real |
| Auxiliares | Configurar caminhos reais e executar DiagnosticarFerramentas | Versão de pdftotext identificada, NAPS2 responde; teste de PDF confirmado |
| Português/Melhor | Conferir configuração do NAPS2 e processar PDF-imagem de teste | OCR por funcionando; páginas preservadas; texto útil recuperado |
| Suíte VBA | TestarCredplus com tests/fixtures | 15 casos efetivamente executados; CSV sem FAIL |
| Reproduzir Zurich | Importar o PDF Zurich recebido, comparar condutor e vidros com a imagem | Sem 615/250/390/285 indevidamente associados às quatro linhas antigas |
| Camada antiga | Importar a cópia OCR antiga que gerou TextoPDF, se disponível; comparar com fixture antigo | Bloco desestruturado sinalizado; valores soltos não redistribuídos |
| OCR forçado | Reprocessar PDF já pesquisável com erro; observar PDF→TIFF→PDF | TIFF multipágina reconhecido; todas as páginas preservadas; nova camada produzida |
| Sem texto / OCR falha | Usar cópia de documento-imagem e configurar caminho NAPS2 inválido ou caso de falha controlado | Erro explícito; cotação anterior preservada; sem exportar estado novo indevido |
| Extrator falha | Configurar caminho inexistente ou auxiliar de teste que retorna erro | Mensagem clara, sem substituir dados |
| Timeout | Em ambiente de teste, auxiliar controlado que demora mais que B13 | Não bloquear indefinidamente; árvore apenas do processo iniciado encerrada/confirmada; estado restaurado |
| Cancelar arquivo | Cancelar o seletor PDF | Valores da cotação anterior intactos |
| Cancelar seguradora/oferta | Selecionar PDF e cancelar cada diálogo | Valores e texto anterior intactos |
| Cancelar durante processo | Usar botão Cancelar importação durante OCR | Auxiliar iniciado encerrado; cotação anterior intacta |
| Recusar incompleto | Cotação sem total; responder Não | Dados anteriores intactos |
| Confirmar incompleto | Cotação sem total; responder Sim | Novo estado incompleto explícito, revisão/exportação bloqueada por obrigatório |
| Uma após outra | HDI → Zurich → Yelum | Nenhum CPF, preço, franquia ou oferta anterior mantido se ausente no novo PDF |
| Falha de gravação | Somente em cópia: impedir gravação/proteger intervalo antes da etapa de commit | Restaurar ou deixar estado incompleto explícito com revisão invalidada; não prometer restauração sem conferir |
| Eventos normais | Confirmar revisão, alterar Dados!B, evidência D, status C e regra | Revisão invalidada; alteração de B marca C como Revisar |
| Após Reset | Confirmar; no VBE usar Reset em repouso; voltar ao Excel e alterar Dados!B | Workbook_SheetChange deve funcionar sem reinicializar sink; exportação exige revisão |
| Colagens | Colar várias células em Dados!B6:B51 | Todas as linhas alteradas marcadas para revisão, sem recursão |
| Estados de ausência | Testar vazio, zero numérico, Nao contratado, Nao se aplica, Nao localizado e Leitura ambigua | Zero não vira vazio; ausências diferenciadas; obrigatório faltante/ambíguo bloqueia |
| Tipos | Tentar CPF como número, data impossível, dinheiro como texto, chassi inválido | Validação impede confirmar/exportar; não corrige caracteres por adivinhação |
| Revisão longa | Evidências que somam mais de 32 mil caracteres | Registro gravado integralmente em partes; alterar uma parte/dado invalida comparação |
| Pagamento | Escolher condição de uma oferta e transcrever meio/parcelas/juros/total | Sem escolher promoção vencida ou inventar condições; divergência de centavos revisada |
| Interface restaurada | Repetir cancelamento e falhas | EnableEvents, ScreenUpdating e StatusBar voltam ao estado anterior |
| Fechar/salvar durante importação | Tentar fechar ou salvar com OCR ativo | Fechamento/salvamento impedido até terminar/cancelar |
| Conversão verdadeira | ConverterParaXLSB em nome novo; conferir FileFormat no Excel | Valor 50, VBA presente; XLSX não apenas renomeado |
| SaveAs e reabertura | Salvar com novo nome; fechar/reabrir; clicar em botões | OnAction aponta para o nome atual, sem salvamento recursivo |
| Preservação visual | Conferir logo, imagem, fórmulas, seis botões antigos e dois novos de diagnóstico/cancelamento | Nenhum elemento perdido; botões fora da impressão |
| Exportação revisada | Após revisão, gerar PDF com novo nome | Somente Cotacao, duas páginas legíveis; sem Dados/Config/Regras/TextoPDF e sem corretora intermediária |
| Texto longo | Usar perfil, assistência e pagamento longos | Sem corte silencioso; bloqueio explícito se não couber; conferência visual obrigatória |
| Arquivo existente | Escolher destino PDF e XLSB já existentes | Não sobrescrever; solicitar nome novo |
| Validade | Tentar exportar cotação vencida | Bloquear; não alterar datas para fazer passar |

## Campos ainda sujeitos a revisão manual

Todos os campos extraídos precisam de conferência, começando em Revisar. Atenção especial a:

- Zurich: tabela de vidros no texto antigo; chassi; CPF do condutor não demonstrado separadamente; placa, combustível e zero km não identificados; APP somente conjunto; meio de pagamento indefinido. Não trocar código A por “reduzida 50%”.
- Tokio: danos morais se o OCR local mantiver RCF-Y, campo do condutor “Próprio Segurado” e sua correspondência com o segurado, forma de pagamento e oficina por produto.
- Allianz: CPF do segurado e franquia só podem ser usados quando recuperados com evidência própria; se faltarem em outra camada, não copiar de outro campo. Exclusivo: diferença de centavo.
- Yelum: CEP de cinco dígitos, sem completar zeros; assistência sem quilômetros definidos; faixa de jovens 18–24, sem trocar por 18–25.
- HDI: escolha VMR/determinado e correspondência da tabela de pagamento à modalidade.

Não há um XLSB corrigido e compilado produzido no Linux. A entrega oferece a base revisada e componentes completos para concluir a instalação e gerar FileFormat 50 no Excel, preservando também o XLSB original.
