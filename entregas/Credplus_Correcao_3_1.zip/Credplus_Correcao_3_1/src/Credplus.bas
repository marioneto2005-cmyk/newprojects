Attribute VB_Name = "Credplus"
Option Explicit

' Credplus 3.1 - imports local PDF text only. No network or Office security changes.
Private ocupado As Boolean
Private cancelado As Boolean
Public SalvandoAcoes As Boolean

Public Sub Auto_Open()
    InicializarCredplus
End Sub

Public Sub InicializarCredplus()
    On Error GoTo Falha
    PrepararPagina
    CriarBotoes
    AtualizarBotoes
    Exit Sub
Falha:
    MsgBox "Inicializacao incompleta: " & Err.Description & ". Confira as cinco abas e uma impressora instalada no Windows.", vbExclamation
End Sub

Private Function Ws(ByVal nome As String) As Worksheet
    Set Ws = ThisWorkbook.Worksheets(nome)
End Function

Private Function RX(ByVal padrao As String) As Object
    Dim r As Object
    Set r = CreateObject("VBScript.RegExp")
    r.Pattern = padrao
    r.IgnoreCase = True
    r.Global = True
    r.MultiLine = True
    Set RX = r
End Function

Private Function Normalizar(ByVal s As String) As String
    Dim a As String, b As String, i As Long
    a = "����������������������������������������������"
    b = "aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC"
    For i = 1 To Len(a)
        s = Replace(s, Mid$(a, i, 1), Mid$(b, i, 1))
    Next i
    s = Replace(s, vbCr, "")
    s = Replace(s, ChrW(160), " ")
    Normalizar = s
End Function

Private Function Recorte(ByVal texto As String, ByVal inicio As String, ByVal fim As String) As String
    Dim p As Long, Q As Long
    If Left$(inicio, 8) = "@ALLIANZ" Then
        Recorte = ColunaAllianz(texto, CLng(Right$(inicio, 1)))
        Exit Function
    End If
    If inicio <> "" Then
        p = InStr(1, texto, inicio, vbTextCompare)
        If p = 0 Then Exit Function
        texto = Mid$(texto, p)
    End If
    If fim <> "" Then
        Q = InStr(Len(inicio) + 1, texto, fim, vbTextCompare)
        If Q > 0 Then texto = Left$(texto, Q - 1)
    End If
    Recorte = texto
End Function

Private Function ColunaAllianz(ByVal t As String, ByVal oferta As Long) As String
    Dim m As Object, h As Object, limites As Object, linha As Variant
    Dim k As Long, esperados As Long, primeiro As Long, pos As Long, tam As Long, Saida As String, celula As String
    If oferta <= 3 Then
        Set m = RX("^ +Basico +Ampliado +Completo[^\n]*").Execute(t)
        k = oferta - 1: esperados = 3
    Else
        Set m = RX("^ +Master +Exclusivo[^\n]*").Execute(t)
        k = oferta - 4: esperados = 2
    End If
    If m.Count <> 1 Then Exit Function
    t = Mid$(t, m(0).FirstIndex + m(0).Length + 1)
    Set m = RX("^ +Master +Exclusivo|\*\* RCF:").Execute(t)
    If m.Count > 0 Then t = Left$(t, m(0).FirstIndex)
    Set h = RX("^.*Coberturas +Limite[^\n]*").Execute(t)
    If h.Count <> 1 Then Exit Function
    Set limites = RX("Limite").Execute(h(0).Value)
    If limites.Count <> esperados Then Exit Function
    primeiro = limites(0).FirstIndex - 4
    pos = limites(k).FirstIndex - 4
    If primeiro < 1 Or pos < 1 Then Exit Function
    For Each linha In Split(t, vbLf)
        If k < limites.Count - 1 Then
            tam = limites(k + 1).FirstIndex - 4 - pos
        Else
            tam = Len(linha)
        End If
        celula = Mid$(linha, pos + 1, tam)
        ' Coverage limit must start at the left of its column, never in the premium subcolumn.
        If RX("RCF\*\* - Danos|APP[*+]{2,3}").Test(Left$(linha, primeiro)) Then
            If Not RX("^[ ]{0,8}[0-9][0-9.,]*[ ]").Test(celula & " ") Then celula = " [LIMITE AUSENTE OU DESALINHADO]"
        End If
        Saida = Saida & Left$(linha, primeiro) & celula & vbLf
    Next linha
    ColunaAllianz = Saida
End Function

Private Function LinhaCampo(ByVal id As String) As Long
    Dim i As Long
    For i = 6 To 51
        If Ws("Dados").Cells(i, 6).Value2 = id Then LinhaCampo = i: Exit Function
    Next i
    Err.Raise vbObjectError + 101, , "Identificador ausente em Dados: " & id
End Function

Private Function Dinheiro(ByVal s As String) As Double
    If Not RX("^([0-9]{1,3}(\.[0-9]{3})*|[0-9]+),[0-9]{2}$").Test(s) Then Err.Raise 5, , "Valor monetario incompleto."
    Dinheiro = Val(Replace(Replace(s, ".", ""), ",", "."))
End Function

Private Function DataBR(ByVal s As String) As Date
    Dim d As Date
    If Not RX("^[0-9]{2}/[0-9]{2}/[0-9]{4}$").Test(s) Then Err.Raise 5, , "Data incompleta."
    d = DateSerial(CLng(Right$(s, 4)), CLng(Mid$(s, 4, 2)), CLng(Left$(s, 2)))
    If Format$(d, "dd/mm/yyyy") <> s Then Err.Raise 5, , "Data invalida."
    DataBR = d
End Function

Private Function DocumentoValido(ByVal s As String) As Boolean
    Dim n As String, i As Long, j As Long, soma As Long, dig As Long, peso As Long
    n = Replace(Replace(Replace(Replace(s, ".", ""), "-", ""), "/", ""), " ", "")
    If Not RX("^([0-9]{11}|[0-9]{14})$").Test(n) Then Exit Function
    If n = String$(Len(n), Left$(n, 1)) Then Exit Function
    For j = Len(n) - 1 To Len(n)
        soma = 0
        If Len(n) = 11 Then
            For i = 1 To j - 1: soma = soma + CLng(Mid$(n, i, 1)) * (j + 1 - i): Next i
        Else
            peso = 2
            For i = j - 1 To 1 Step -1
                soma = soma + CLng(Mid$(n, i, 1)) * peso
                peso = peso + 1: If peso = 10 Then peso = 2
            Next i
        End If
        dig = 11 - (soma Mod 11): If dig > 9 Then dig = 0
        If dig <> CLng(Mid$(n, j, 1)) Then Exit Function
    Next j
    DocumentoValido = True
End Function

Private Function IdentificadorValido(ByVal id As String, ByVal s As String) As Boolean
    Select Case id
        Case "cpf", "cpfcond": IdentificadorValido = DocumentoValido(s)
        Case "cep": IdentificadorValido = RX("^[0-9]{8}$").Test(Replace(Replace(s, " ", ""), "-", ""))
        Case "placa": IdentificadorValido = RX("^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$").Test(Replace(s, "-", ""))
        Case "chassi": IdentificadorValido = RX("^[A-HJ-NPR-Z0-9]{17}$").Test(s)
        Case Else: IdentificadorValido = True
    End Select
End Function

Private Sub ExtrairCampos(ByVal texto As String, ByVal seguradora As String, ByVal oferta As Long, ByRef valores As Variant)
    Dim regras As Variant, r As Long, j As Long, grupo As Long, id As String, tipo As String
    Dim original As String, normal As String, trecho As String, ms As Object, m As Object, v As String, ev As String, amb As Boolean
    VerificarEstrutura
    regras = Ws("Regras").Range("A6:H" & Ws("Regras").Cells(Ws("Regras").Rows.Count, 1).End(xlUp).Row).Value2
    If UBound(regras, 1) < 1 Then Err.Raise 5, , "Sem regras de extracao."
    ReDim valores(1 To 46, 1 To 3)
    For j = 1 To 46: valores(j, 2) = "Nao localizado": Next j
    For r = 1 To UBound(regras, 1)
        If regras(r, 1) = seguradora And (CStr(regras(r, 8)) = "*" Or CStr(regras(r, 8)) = CStr(oferta)) Then
            id = CStr(regras(r, 2)): j = LinhaCampo(id) - 5
            tipo = CStr(regras(r, 7)): grupo = CLng(regras(r, 6))
            ' Normalization preserves character offsets, so evidence and names retain accents.
            normal = Recorte(Normalizar(texto), CStr(regras(r, 3)), CStr(regras(r, 4)))
            original = RecorteOriginal(texto, CStr(regras(r, 3)), CStr(regras(r, 4)))
            Set ms = RX(CStr(regras(r, 5))).Execute(normal)
            If ms.Count > 0 Then
                If grupo < 1 Or grupo > ms(0).SubMatches.Count Then Err.Raise 5, , "Grupo invalido na regra " & r + 5
                v = Trim$(ms(0).SubMatches(grupo - 1)): amb = False
                For Each m In ms
                    If Trim$(m.SubMatches(grupo - 1)) <> v Then amb = True
                Next m
                ev = Mid$(original, ms(0).FirstIndex + 1, ms(0).Length)
                If Len(ev) = 0 Then ev = ms(0).Value
                valores(j, 3) = Left$(ev, 32000)
                If amb Then
                    valores(j, 1) = Empty
                    valores(j, 2) = "Leitura ambigua"
                Else
                    If tipo = "T" Then
                        ' Match normalized subgroup in the original match at the same character offset.
                        Dim subPos As Long
                        subPos = InStr(1, ms(0).Value, ms(0).SubMatches(grupo - 1), vbBinaryCompare)
                        If subPos > 0 And Len(ev) = ms(0).Length Then v = Trim$(Mid$(ev, subPos, Len(ms(0).SubMatches(grupo - 1))))
                        If id = "jovens" And ms(0).SubMatches.Count > 1 Then v = Trim$(ev)
                    End If
                    If valores(j, 2) <> "Leitura ambigua" Then valores(j, 2) = "Revisar"
                    Dim convertido As Variant
                    If TentarConverter(tipo, v, convertido) Then
                        If Not IsEmpty(valores(j, 1)) Then
                            If CStr(valores(j, 1)) <> CStr(convertido) Then amb = True
                        End If
                        If valores(j, 2) = "Leitura ambigua" Then amb = True
                        valores(j, 1) = convertido
                    Else
                        amb = True
                    End If
                    If amb Then
                        valores(j, 1) = Empty
                        valores(j, 2) = "Leitura ambigua"
                    End If
                    If id = "cep" And Not amb Then valores(j, 1) = Replace(Replace(v, " ", ""), "-", "")
                    If Not IdentificadorValido(id, CStr(valores(j, 1))) Then
                        valores(j, 1) = Empty
                        valores(j, 2) = "Leitura ambigua"
                    End If
                End If
            End If
        End If
    Next r
    If seguradora = "Zurich" Then VerificarTabelaZurich texto, valores
    j = LinhaCampo("seguradora") - 5: valores(j, 1) = seguradora: valores(j, 2) = "Revisar": valores(j, 3) = "Seguradora confirmada pelo operador"
    j = LinhaCampo("oferta") - 5: valores(j, 1) = NomeOferta(seguradora, oferta): valores(j, 2) = "Revisar": valores(j, 3) = "Oferta escolhida pelo operador"
    j = LinhaCampo("pagamento") - 5
    valores(j, 3) = "Escolha e transcreva meio, entrada, quantidade, valor, juros e total da opcao desejada. Consulte TextoPDF e o PDF original."
    If seguradora = "Allianz" Then
        valores(j, 3) = valores(j, 3) & " Nao vincular automaticamente a linha de 10 parcelas ao premio da cobertura."
        VerificarDiferencaAllianz texto, oferta, valores
        valores(j, 3) = valores(j, 3) & vbLf & Left$(RecorteOriginal(texto, "OUTRAS FORMAS DE PAGAMENTO", "SEU CORRETOR"), 2600)
    ElseIf seguradora = "Tokio Marine" Then
        valores(j, 3) = valores(j, 3) & " Premio normal da linha 1 Sem Juros em Debito/Pix. Desconto antecipado nao utilizado."
        valores(j, 3) = valores(j, 3) & vbLf & Left$(RecorteOriginal(texto, "PAGAMENTOS", "Ficha"), 2600)
        j = LinhaCampo("casco") - 5
        If Not IsEmpty(valores(j, 1)) Then valores(j, 1) = "VMR - " & valores(j, 1)
        j = LinhaCampo("observacoes") - 5
        If Not IsEmpty(valores(j, 1)) Then valores(j, 1) = "Oficina para reparo: " & valores(j, 1)
    ElseIf seguradora = "Zurich" Then
        valores(j, 3) = valores(j, 3) & " Meio de pagamento nao identificado no texto."
        valores(j, 3) = valores(j, 3) & vbLf & Left$(RecorteOriginal(texto, "Data da Entrada", "INFORMACOES DA SEGURADORA"), 2600)
    ElseIf seguradora = "HDI" Then
        valores(j, 3) = valores(j, 3) & vbLf & Left$(RecorteOriginal(texto, "Parcelamento Vlr.", "Assinatura do Proponente"), 2600)
    ElseIf seguradora = "Yelum" Then
        valores(j, 3) = valores(j, 3) & vbLf & Left$(RecorteOriginal(texto, "FORMA DE PAGAMENTO:", "ITEM 1"), 2600)
    End If
End Sub

Private Function RecorteOriginal(ByVal t As String, ByVal ini As String, ByVal fim As String) As String
    Dim n As String, p As Long, Q As Long
    If Left$(ini, 8) = "@ALLIANZ" Then
        ' Table evidence is normalized; the full unmodified text remains in TextoPDF.
        RecorteOriginal = ColunaAllianz(Normalizar(t), CLng(Right$(ini, 1))): Exit Function
    End If
    n = Normalizar(t): t = Replace(Replace(t, vbCr, ""), ChrW(160), " ")
    If ini <> "" Then
        p = InStr(1, n, ini, vbTextCompare): If p = 0 Then Exit Function
        t = Mid$(t, p): n = Mid$(n, p)
    End If
    If fim <> "" Then
        Q = InStr(Len(ini) + 1, n, fim, vbTextCompare)
        If Q > 0 Then t = Left$(t, Q - 1)
    End If
    RecorteOriginal = t
End Function

Private Sub VerificarDiferencaAllianz(ByVal t As String, ByVal oferta As Long, ByRef v As Variant)
    Dim m As Object, nums As Object, j As Long, n As Double
    t = Recorte(Normalizar(t), "OUTRAS FORMAS DE PAGAMENTO", "SEU CORRETOR")
    Set m = RX("^[ ]*sem juros[^\n]+").Execute(t)
    If m.Count = 0 Then Exit Sub
    Set nums = RX("[0-9]+\.[0-9]{3},[0-9]{2}").Execute(m(0).Value)
    If nums.Count <> 5 Then Exit Sub
    j = LinhaCampo("total") - 5
    If IsEmpty(v(j, 1)) Then Exit Sub
    n = Dinheiro(nums(oferta - 1).Value)
    If Abs(n - CDbl(v(j, 1))) > 0.005 Then
        v(j, 2) = "Revisar divergencia"
        v(j, 3) = v(j, 3) & vbLf & "Pagamento: " & nums(oferta - 1).Value & "; mantido premio da tabela de coberturas."
    End If
End Sub

Private Function NomeOferta(ByVal s As String, ByVal n As Long) As String
    Select Case s
        Case "Allianz": NomeOferta = Split("Basico|Ampliado|Completo|Master|Exclusivo", "|")(n - 1)
        Case "Tokio Marine": NomeOferta = Split("Auto|Auto Classico", "|")(n - 1)
        Case "HDI": NomeOferta = Split("Valor de Mercado Referenciado|Valor Determinado", "|")(n - 1)
        Case Else: NomeOferta = "Oferta unica do documento"
    End Select
End Function

Private Function Q(ByVal s As String) As String
    If InStr(s, Chr$(34)) > 0 Or InStr(s, vbCr) > 0 Or InStr(s, vbLf) > 0 Then Err.Raise 5, , "Aspas invalidas no caminho."
    Q = Chr$(34) & s & Chr$(34)
End Function

Private Sub Executar(ByVal comando As String, ByVal limite As Long, ByVal log As String)
    Dim proc As Object, shell As Object, prazo As Date, saida As String, pid As Long
    Set shell = CreateObject("WScript.Shell")
    If limite < 10 Or limite > 3600 Then Err.Raise 5, , "Timeout invalido."
    If InStr(comando & log, "%") > 0 Or InStr(comando & log, "!") > 0 Then Err.Raise 5, , "Caminhos contendo % ou ! nao sao aceitos pelo executor."
    ' Redirect both pipes to a file: no pipe buffer deadlock while polling.
    Set proc = shell.Exec(Q(Environ$("ComSpec")) & " /d /s /c " & Chr$(34) & comando & " 1>" & Q(log) & " 2>&1" & Chr$(34))
    pid = proc.ProcessID
    prazo = DateAdd("s", limite, Now)
    Do While proc.Status = 0
        DoEvents
        If Now >= prazo Or cancelado Then
            shell.Run Q(Environ$("SystemRoot") & "\System32\taskkill.exe") & " /PID " & CStr(pid) & " /T /F", 0, True
            If cancelado Then Err.Raise vbObjectError + 112, , "Cancelado pelo operador."
            Err.Raise vbObjectError + 110, , "Tempo limite excedido; encerramento solicitado para a arvore do processo iniciado."
        End If
    Loop
    If proc.ExitCode <> 0 Then
        On Error Resume Next
        saida = LerUTF8(log)
        On Error GoTo 0
        Err.Raise vbObjectError + 111, , "Falha no programa auxiliar (" & proc.ExitCode & "): " & Left$(saida, 1500)
    End If
End Sub

Private Function LerUTF8(ByVal caminho As String) As String
    Dim st As Object
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2: st.Charset = "utf-8": st.Open
    st.LoadFromFile caminho: LerUTF8 = st.ReadText: st.Close
End Function

Public Sub ImportarPDF()
    Importacao False
End Sub

Public Sub ReprocessarComOCR()
    Importacao True
End Sub

Private Sub Importacao(ByVal forcar As Boolean)
    Dim escolha As Variant, fs As Object, pasta As String, texto As String, exe As String, naps As String
    Dim oldEvents As Boolean, oldScreen As Boolean, oldStatus As Variant, mudou As Boolean
    Dim anterior As Variant, conf As Variant, diag As Variant, assinatura As Variant, novos As Variant
    Dim seg As String, resposta As Variant, oferta As Long, maxOferta As Long, sugestao As String
    Dim i As Long, linhas As Variant, n As Long, limite As Long, mensagem As String, snap As Boolean
    Dim formatos(1 To 46) As String, revisaoFim As Long, rollbackFalhou As Boolean
    If ocupado Then Exit Sub
    cancelado = False
    escolha = Application.GetOpenFilename("Arquivos PDF (*.pdf),*.pdf", , "Selecione UMA cotacao")
    If VarType(escolha) = vbBoolean Then Exit Sub
    ocupado = True
    oldEvents = Application.EnableEvents: oldScreen = Application.ScreenUpdating: oldStatus = Application.StatusBar
    On Error GoTo Falha
    Set fs = CreateObject("Scripting.FileSystemObject")
    exe = Trim$(Ws("Config").Range("B5").Value2)
    If exe = "" Or Not fs.FileExists(exe) Then Err.Raise 5, , "Configure Config!B5 com pdftotext.exe. Word nao e usado para tabelas."
    limite = CLng(Ws("Config").Range("B13").Value2)
    If limite < 10 Or limite > 3600 Then Err.Raise 5, , "Tempo limite deve estar entre 10 e 3600 segundos."
    pasta = fs.BuildPath(fs.GetSpecialFolder(2), "Credplus_" & fs.GetTempName)
    fs.CreateFolder pasta
    fs.CopyFile CStr(escolha), pasta & "\entrada.pdf", False
    Application.StatusBar = "Credplus: extraindo texto localmente..."
    Executar Q(exe) & " -layout -enc UTF-8 " & Q(pasta & "\entrada.pdf") & " " & Q(pasta & "\texto.txt"), limite, pasta & "\processo.log"
    texto = LerUTF8(pasta & "\texto.txt")
    If forcar Or (Len(Trim$(texto)) < 150 And LCase$(Trim$(Ws("Config").Range("B6").Value2)) = "sim") Then
        naps = Trim$(Ws("Config").Range("B4").Value2)
        If naps = "" Or Not fs.FileExists(naps) Then Err.Raise 5, , "Configure Config!B4 com NAPS2.Console.exe."
        If LCase$(Trim$(Ws("Config").Range("B7").Value2)) <> "por" Then Err.Raise 5, , "Esta versao requer idioma OCR por."
        Application.StatusBar = "Credplus: NAPS2 executando OCR na copia temporaria..."
        Dim fonteOCR As String
        fonteOCR = pasta & "\entrada.pdf"
        If forcar Then
            ' Rasterize a copy through multipage TIFF: NAPS2 may skip pages with existing text.
            Executar Q(naps) & " -i " & Q(fonteOCR) & " -o " & Q(pasta & "\raster.tiff") & " -n 0 --disableocr", limite, pasta & "\processo.log"
            If Not fs.FileExists(pasta & "\raster.tiff") Then Err.Raise 5, , "NAPS2 nao produziu TIFF multipagina."
            fonteOCR = pasta & "\raster.tiff"
        End If
        Executar Q(naps) & " -i " & Q(fonteOCR) & " -o " & Q(pasta & "\ocr.pdf") & " -n 0 --ocrlang por", limite, pasta & "\processo.log"
        If Not fs.FileExists(pasta & "\ocr.pdf") Then Err.Raise 5, , "NAPS2 nao produziu PDF."
        Executar Q(exe) & " -layout -enc UTF-8 " & Q(pasta & "\ocr.pdf") & " " & Q(pasta & "\texto_ocr.txt"), limite, pasta & "\processo.log"
        texto = LerUTF8(pasta & "\texto_ocr.txt")
        If forcar Then
            If texto = LerUTF8(pasta & "\texto.txt") Then Err.Raise 5, , "OCR nao alterou o texto. Confira visualmente; nenhum dado foi substituido."
        End If
    End If
    If Len(Trim$(texto)) < 150 Then Err.Raise 5, , "Texto insuficiente. Ative OCR ou use Reprocessar com OCR."
    sugestao = ""
    ' Only header/title signals; references to the previous insurer are ignored.
    If InStr(1, Left$(texto, 1000), "Allianz", vbTextCompare) > 0 Then sugestao = "Allianz"
    If InStr(1, Left$(texto, 1000), "TOKIO", vbTextCompare) > 0 Then sugestao = "Tokio Marine"
    If InStr(1, Left$(texto, 1000), "HDI", vbTextCompare) > 0 Then sugestao = "HDI"
    If InStr(1, Left$(texto, 1000), "ZURICH", vbTextCompare) > 0 Then sugestao = "Zurich"
    If InStr(1, Left$(texto, 1000), "Yelum", vbTextCompare) > 0 Then sugestao = "Yelum"
    resposta = Application.InputBox("Confirme: Allianz, HDI, Tokio Marine, Yelum ou Zurich", "Seguradora", sugestao, Type:=2)
    If VarType(resposta) = vbBoolean Then GoTo Saida
    seg = Trim$(CStr(resposta))
    Select Case LCase$(seg)
        Case "allianz": seg = "Allianz": maxOferta = 5
        Case "hdi": seg = "HDI": maxOferta = 2
        Case "tokio marine": seg = "Tokio Marine": maxOferta = 2
        Case "yelum": seg = "Yelum": maxOferta = 1
        Case "zurich": seg = "Zurich": maxOferta = 1
        Case Else: Err.Raise 5, , "Seguradora nao suportada. Nenhum dado foi substituido."
    End Select
    oferta = 1
    If maxOferta > 1 Then
        mensagem = "Escolha pelo numero:" & vbCrLf
        For i = 1 To maxOferta: mensagem = mensagem & i & " - " & NomeOferta(seg, i) & vbCrLf: Next i
        resposta = Application.InputBox(mensagem, "Oferta obrigatoria", Type:=1)
        If VarType(resposta) = vbBoolean Then GoTo Saida
        If resposta <> Fix(resposta) Or resposta < 1 Or resposta > maxOferta Then Err.Raise 5, , "Oferta invalida."
        oferta = CLng(resposta)
    End If
    If cancelado Then GoTo Saida
    ExtrairCampos texto, seg, oferta, novos
    If IsEmpty(novos(LinhaCampo("total") - 5, 1)) Then
        If MsgBox("Premio nao localizado. Importar como INCOMPLETO para revisao manual?", vbYesNo + vbExclamation) <> vbYes Then GoTo Saida
    End If
    If cancelado Then GoTo Saida
    anterior = Ws("Dados").Range("B6:D51").Value2
    For i = 1 To 46: formatos(i) = Ws("Dados").Cells(i + 5, 2).NumberFormat: Next i
    conf = Ws("Config").Range("B10:B12").Value2
    revisaoFim = Application.Max(4, Ws("Config").Cells(Ws("Config").Rows.Count, 4).End(xlUp).Row)
    assinatura = Ws("Config").Range("D4:D" & revisaoFim).Value2
    n = Ws("TextoPDF").UsedRange.Rows.Count
    diag = Ws("TextoPDF").Range("A1:B" & n).Value2: snap = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    mudou = True
    Ws("Dados").Range("B6:B51").NumberFormat = "@"
    Ws("Dados").Range("C6:D51").NumberFormat = "@"
    For i = 1 To 46
        If Ws("Dados").Cells(i + 5, 7).Value2 = "N" Or (Ws("Dados").Cells(i + 5, 6).Value2 = "casco" And seg = "HDI" And oferta = 2) Then
            Ws("Dados").Cells(i + 5, 2).NumberFormat = """R$"" #,##0.00"
        ElseIf Ws("Dados").Cells(i + 5, 7).Value2 = "D" Then
            Ws("Dados").Cells(i + 5, 2).NumberFormat = "dd/mm/yyyy"
        End If
    Next i
    Ws("Dados").Range("B6:D51").Value = novos
    Ws("Config").Range("B10").Value2 = CStr(escolha)
    Ws("Config").Range("B11").Value = Now
    Ws("Config").Range("B12").Value2 = "Importado - revisao obrigatoria"
    Ws("Config").Range("D4").ClearContents
    Ws("TextoPDF").Range("A:B").ClearContents
    Ws("TextoPDF").Range("A1:B1").Value = Array("Linha", "Texto extraido (uso interno)")
    GravarTextoCompleto texto
    MsgBox "Importado. Revise Dados!B6:B51 e a evidencia na coluna D. Para cada linha, defina C como Revisado, Nao contratado, Nao se aplica ou Nao localizado. Campos obrigatorios faltantes bloqueiam a exportacao.", vbInformation
    GoTo Saida
Falha:
    mensagem = Err.Description
    On Error Resume Next
    Err.Clear
    If mudou And snap Then
        For i = 1 To 46: Ws("Dados").Cells(i + 5, 2).NumberFormat = formatos(i): Next i
        Ws("Dados").Range("B6:D51").Value2 = anterior
        Ws("Config").Range("B10:B12").Value2 = conf
        Ws("Config").Range("D4:D" & revisaoFim).Value2 = assinatura
        Ws("TextoPDF").Range("A:B").ClearContents
        Ws("TextoPDF").Range("A1:B" & n).Value2 = diag
        rollbackFalhou = (Err.Number <> 0)
        Ws("Config").Range("D4").ClearContents
        Ws("Config").Range("B12").Value2 = "Falha na gravacao - revisao obrigatoria"
    End If
    If mudou Then
        MsgBox "Falha ao gravar: " & mensagem & vbCrLf & "Foi tentada a restauracao; exportacao exige nova revisao. Confira Dados e TextoPDF. Falha na restauracao: " & CStr(rollbackFalhou), vbCritical
    Else
        MsgBox "Importacao cancelada: " & mensagem & vbCrLf & "A cotacao anterior nao foi substituida.", vbExclamation
    End If
Saida:
    On Error Resume Next
    ' Delete only known files within the unique directory created by this call.
    If pasta <> "" Then
        Dim arq As Variant
        For Each arq In Array("entrada.pdf", "ocr.pdf", "texto.txt", "texto_ocr.txt", "raster.tiff", "processo.log")
            If fs.FileExists(pasta & "\" & arq) Then fs.DeleteFile pasta & "\" & arq, True
        Next arq
        RmDir pasta
    End If
    Application.EnableEvents = oldEvents: Application.ScreenUpdating = oldScreen: Application.StatusBar = oldStatus
    ocupado = False
End Sub

Public Sub InvalidarRevisao()
    Ws("Config").Range("D4").ClearContents
    Ws("Config").Range("B12").Value2 = "Alterado - revisao obrigatoria"
End Sub

Private Function AssinaturaAtual() As String
    Dim cel As Range, s As String, v As String, r As Long, sh As Shape
    For Each cel In Ws("Dados").Range("A6:G51")
        v = CStr(cel.Value2): s = s & Len(v) & ":" & v & ";"
    Next cel
    For Each cel In Ws("Config").Range("B4:B11")
        v = CStr(cel.Value2): s = s & Len(v) & ":" & v & ";"
    Next cel
    For Each cel In Ws("Regras").Range("A6:H" & Ws("Regras").Cells(Ws("Regras").Rows.Count, 1).End(xlUp).Row)
        v = CStr(cel.Value2): s = s & Len(v) & ":" & v & ";"
    Next cel
    For Each cel In Ws("Cotacao").Range("A1:H62")
        v = CStr(cel.Formula) & "|" & CStr(cel.Value2) & "|" & cel.NumberFormat & "|" & cel.Font.Size & "|" & cel.Font.Name
        v = v & "|" & cel.MergeArea.Address & "|" & cel.WrapText & "|" & cel.Font.Bold & "|" & cel.Font.Color & "|" & cel.Interior.Color & "|" & cel.HorizontalAlignment & "|" & cel.VerticalAlignment
        s = s & Len(v) & ":" & v & ";"
    Next cel
    For r = 1 To 62: s = s & "R" & r & ":" & Ws("Cotacao").Rows(r).RowHeight & "|" & Ws("Cotacao").Rows(r).Hidden & ";": Next r
    For r = 1 To 8: s = s & "C" & r & ":" & Ws("Cotacao").Columns(r).ColumnWidth & "|" & Ws("Cotacao").Columns(r).Hidden & ";": Next r
    For Each sh In Ws("Cotacao").Shapes
        If Left$(sh.Name, 3) <> "cp_" Then s = s & sh.Name & "|" & sh.Type & "|" & sh.Left & "|" & sh.Top & "|" & sh.Width & "|" & sh.Height & ";"
    Next sh
    With Ws("Cotacao").PageSetup
        s = s & .PrintArea & "|" & .CenterFooter & "|" & .LeftFooter & "|" & .RightFooter
        s = s & "|" & .LeftHeader & "|" & .CenterHeader & "|" & .RightHeader
        s = s & "|" & .LeftMargin & "|" & .RightMargin & "|" & .TopMargin & "|" & .BottomMargin & "|" & .HeaderMargin & "|" & .FooterMargin
        s = s & "|" & .PaperSize & "|" & .Orientation & "|" & .PrintTitleRows & "|" & .PrintTitleColumns
    End With
    AssinaturaAtual = s
End Function

Private Function ValidarDados() As Boolean
    Dim i As Long, id As String, v As Variant, st As String, obrig As Boolean, tipo As String
    VerificarEstrutura
    For i = 6 To 51
        id = Ws("Dados").Cells(i, 6).Value2: v = Ws("Dados").Cells(i, 2).Value2
        st = CStr(Ws("Dados").Cells(i, 3).Value2): obrig = (Ws("Dados").Cells(i, 5).Value2 = "Sim")
        tipo = Ws("Dados").Cells(i, 7).Value2
        If obrig And Len(Trim$(CStr(v))) = 0 Then
            If (id = "dm" Or id = "dc" Or id = "casco" Or id = "franquia") And (st = "Nao contratado" Or st = "Nao se aplica") Then
                ' Explicit reviewed absence is different from zero or missing extraction.
            Else
                GoTo Pendente
            End If
        End If
        If st <> "Revisado" And st <> "Nao contratado" And st <> "Nao se aplica" And st <> "Nao localizado" Then GoTo Pendente
        If st = "Nao localizado" And obrig Then GoTo Pendente
        If Len(CStr(v)) > 0 Then
            If st <> "Revisado" Then GoTo Pendente
            If Not IdentificadorValido(id, CStr(v)) Then GoTo Pendente
            If InStr(",cpf,cpfcond,cep,placa,chassi,", "," & id & ",") > 0 Then
                If VarType(v) <> vbString Then GoTo Pendente
            End If
            If id = "casco" And Ws("Dados").Cells(LinhaCampo("seguradora"), 2).Value2 = "HDI" Then
                If Ws("Dados").Cells(LinhaCampo("oferta"), 2).Value2 = "Valor Determinado" Then
                    If VarType(v) = vbString Or Not IsNumeric(v) Then GoTo Pendente
                End If
            End If
            If tipo = "N" Or (id = "casco" And IsNumeric(v) And VarType(v) <> vbString) Then
                If VarType(v) = vbString Or Not IsNumeric(v) Then GoTo Pendente
                If CDbl(v) < 0 Then GoTo Pendente
            End If
            If tipo = "D" Then
                If VarType(v) = vbString Or Not IsNumeric(v) Then GoTo Pendente
                If CDbl(v) < 36526 Or CDbl(v) > 73415 Then GoTo Pendente
                If CDbl(v) <> Fix(CDbl(v)) Then GoTo Pendente
            End If
        ElseIf st = "Revisado" Then
            GoTo Pendente
        End If
    Next i
    If Ws("Dados").Cells(LinhaCampo("fim"), 2).Value2 <= Ws("Dados").Cells(LinhaCampo("inicio"), 2).Value2 Then
        MsgBox "Fim da vigencia deve ser posterior ao inicio.", vbExclamation: Exit Function
    End If
    ValidarDados = True: Exit Function
Pendente:
    MsgBox "Revise Dados, linha " & i & ": " & Ws("Dados").Cells(i, 1).Value2 & ". Verifique valor, tipo e situacao.", vbExclamation
End Function

Public Sub ConfirmarRevisao()
    On Error GoTo Falha
    If ocupado Then Exit Sub
    PrepararPagina
    Ws("Cotacao").Calculate
    If Not ValidarDados Then Exit Sub
    If Not ValidarLayout Then Exit Sub
    If MsgBox("Conferiu no PDF original os dados, produto, coberturas, franquias, pagamento e ausencia de dados da corretora intermediaria?", vbYesNo + vbQuestion) <> vbYes Then Exit Sub
    GuardarRevisao AssinaturaAtual()
    Ws("Config").Range("B12").Value2 = "Revisado em " & Format$(Now, "dd/mm/yyyy hh:nn")
    Exit Sub
Falha:
    MsgBox Err.Description, vbExclamation
End Sub

' Test seam: no writes, dialogs, processes or filesystem access.
Public Function ExtrairTextoParaTeste(ByVal texto As String, ByVal seguradora As String, ByVal oferta As Long) As Variant
    Dim resultado As Variant
    ExtrairCampos texto, seguradora, oferta, resultado
    ExtrairTextoParaTeste = resultado
End Function

Public Sub ExportarPDFCliente()
    Dim destino As Variant, f As Object
    On Error GoTo Falha
    If ThisWorkbook.FileFormat <> 50 And ThisWorkbook.FileFormat <> 52 Then Err.Raise 5, , "Salve como XLSB com ConverterParaXLSB. XLSM tambem e aceito."
    If ocupado Then Exit Sub
    PrepararPagina
    Ws("Cotacao").Calculate
    If Not ValidarDados Then Exit Sub
    If Not ValidarLayout Then Exit Sub
    If Not RevisaoConfere(AssinaturaAtual()) Then
        InvalidarRevisao
        Err.Raise 5, , "Confirme novamente a revisao."
    End If
    Set f = Nothing
    On Error Resume Next
    Set f = Ws("Cotacao").Shapes("LogoCredplus")
    On Error GoTo Falha
    If f Is Nothing Then Err.Raise 5, , "Insira a logomarca oficial com InserirLogomarca antes de exportar."
    If Ws("Dados").Cells(LinhaCampo("validade"), 2).Value < Date Then Err.Raise 5, , "Cotacao vencida. Obtenha nova cotacao."
    destino = Application.GetSaveAsFilename("Cotacao_Credplus_" & Format$(Now, "yyyymmdd_hhnnss") & ".pdf", "PDF (*.pdf),*.pdf")
    If VarType(destino) = vbBoolean Then Exit Sub
    If LCase$(Right$(CStr(destino), 4)) <> ".pdf" Then destino = CStr(destino) & ".pdf"
    Set f = CreateObject("Scripting.FileSystemObject")
    If f.FileExists(CStr(destino)) Then Err.Raise 5, , "Escolha um novo nome. Arquivo existente nao sera sobrescrito."
    Ws("Cotacao").ExportAsFixedFormat Type:=xlTypePDF, Filename:=CStr(destino), Quality:=xlQualityStandard, IncludeDocProperties:=False, IgnorePrintAreas:=False, OpenAfterPublish:=True
    Exit Sub
Falha:
    MsgBox Err.Description, vbExclamation
End Sub

Public Sub PrepararPagina()
    With Ws("Cotacao").PageSetup
        .PrintArea = "$A$1:$H$62"
        .PaperSize = xlPaperA4: .Orientation = xlPortrait
        .Zoom = False: .FitToPagesWide = 1: .FitToPagesTall = False
        .LeftMargin = Application.CentimetersToPoints(1)
        .RightMargin = Application.CentimetersToPoints(1)
        .TopMargin = Application.CentimetersToPoints(1)
        .BottomMargin = Application.CentimetersToPoints(1)
        .HeaderMargin = Application.CentimetersToPoints(0.3)
        .FooterMargin = Application.CentimetersToPoints(0.3)
        .CenterHorizontally = True
        .CenterFooter = "Sicoob Credplus | &P de &N"
    End With
    Ws("Cotacao").ResetAllPageBreaks
    Ws("Cotacao").HPageBreaks.Add Before:=Ws("Cotacao").Range("A33")
End Sub

Private Sub CriarBotoes()
    Dim nomes As Variant, titulos As Variant, i As Long, s As Shape
    nomes = Array("ImportarPDF", "ReprocessarComOCR", "ConfirmarRevisao", "ExportarPDFCliente", "ConverterParaXLSB", "InserirLogomarca", "CancelarImportacao", "DiagnosticarFerramentas")
    titulos = Array("Importar PDF + OCR", "Reprocessar com OCR", "Confirmar revisao", "Gerar PDF cliente", "Converter para XLSB", "Inserir logomarca", "Cancelar importacao", "Verificar ferramentas")
    For i = 0 To UBound(nomes)
        Set s = Nothing
        On Error Resume Next
        Set s = Ws("Cotacao").Shapes("cp_" & nomes(i))
        On Error GoTo 0
        If s Is Nothing Then
            Set s = Ws("Cotacao").Shapes.AddShape(5, Ws("Cotacao").Range("J2").Left, 25 + 40 * i, 175, 32)
            s.Name = "cp_" & nomes(i)
            s.TextFrame.Characters.Text = titulos(i)
            s.Fill.ForeColor.RGB = RGB(0, 78, 76)
            s.TextFrame.Characters.Font.Color = RGB(255, 255, 255)
            s.DrawingObject.PrintObject = False
        End If
    Next i
End Sub

Public Function AtualizarBotoes() As Boolean
    Dim s As Shape, acao As String
    For Each s In Ws("Cotacao").Shapes
        If Left$(s.Name, 3) = "cp_" Then
            acao = "'" & Replace(ThisWorkbook.Name, "'", "''") & "'!" & Mid$(s.Name, 4)
            If s.OnAction <> acao Then s.OnAction = acao: AtualizarBotoes = True
        End If
    Next s
End Function

Public Sub ConverterParaXLSB()
    Dim caminho As Variant, f As Object
    On Error GoTo Falha
    If ocupado Then Exit Sub
    caminho = Application.GetSaveAsFilename("Cotacao_Credplus.xlsb", "Pasta binaria do Excel (*.xlsb),*.xlsb")
    If VarType(caminho) = vbBoolean Then Exit Sub
    If LCase$(Right$(CStr(caminho), 5)) <> ".xlsb" Then caminho = CStr(caminho) & ".xlsb"
    Set f = CreateObject("Scripting.FileSystemObject")
    If f.FileExists(CStr(caminho)) Then Err.Raise 5, , "Escolha um novo nome para preservar o arquivo existente."
    ThisWorkbook.SaveAs Filename:=CStr(caminho), FileFormat:=50, CreateBackup:=False
    If ThisWorkbook.FileFormat <> 50 Then Err.Raise 5, , "Conversao nao confirmada."
    AtualizarBotoes
    ThisWorkbook.Save
    MsgBox "XLSB real salvo. Feche e reabra; confira logomarca, formulas, botoes e duas paginas antes do uso.", vbInformation
    Exit Sub
Falha:
    MsgBox Err.Description, vbExclamation
End Sub

Public Sub InserirLogomarca()
    Dim caminho As Variant, s As Shape, nova As Shape
    On Error GoTo Falha
    If ocupado Then Exit Sub
    caminho = Application.GetOpenFilename("Imagens (*.jpg;*.jpeg;*.png),*.jpg;*.jpeg;*.png", , "Selecione a logomarca oficial Credplus horizontal")
    If VarType(caminho) = vbBoolean Then Exit Sub
    Set nova = Ws("Cotacao").Shapes.AddPicture(CStr(caminho), False, True, 10, 4, -1, -1)
    nova.LockAspectRatio = True: nova.Width = 155
    If nova.Height > 48 Then nova.Height = 48
    On Error Resume Next
    Ws("Cotacao").Shapes("LogoCredplus").Delete
    On Error GoTo Falha
    nova.Name = "LogoCredplus"
    InvalidarRevisao
    Exit Sub
Falha:
    MsgBox Err.Description, vbExclamation
End Sub


Public Function EmImportacao() As Boolean
    EmImportacao = ocupado
End Function

Public Sub CancelarImportacao()
    cancelado = True
End Sub

Private Sub VerificarEstrutura()
    Dim ids As Variant, i As Long, id As String, esperado As String
    ids = Split("nome,cpf,condutor,cpfcond,seguradora,validade,inicio,fim,uso,trabalho,faculdade,garagem,jovens,cep,modelo,ano,placa,chassi,combustivel,zero,oferta,casco,dm,dc,appm,appi,appg,morais,vidros,assistencia,reserva,franquia,tipofranquia,parabrisa,laterais,traseiro,farol,farolled,lanterna,lanternaled,retrovisor,auxiliar,lanternaaux,total,pagamento,observacoes", ",")
    If Ws("Config").Range("F4").Value2 <> "CREDPLUS-3.1" Then Err.Raise 5, , "Execute AplicarCorrecaoCredplus para instalar as regras e formulas desta versao."
    For i = 0 To UBound(ids)
        id = CStr(ids(i))
        If Ws("Dados").Cells(i + 6, 6).Value2 <> id Then Err.Raise 5, , "Estrutura alterada em Dados!F" & i + 6
        esperado = "T"
        If i >= 5 And i <= 7 Then esperado = "D"
        If InStr(",dm,dc,appm,appi,appg,morais,franquia,parabrisa,laterais,traseiro,farol,farolled,lanterna,lanternaled,retrovisor,auxiliar,lanternaaux,total,", "," & id & ",") > 0 Then esperado = "N"
        If Ws("Dados").Cells(i + 6, 7).Value2 <> esperado Then Err.Raise 5, , "Tipo incorreto em Dados!G" & i + 6
    Next i
End Sub

Private Function TentarConverter(ByVal tipo As String, ByVal s As String, ByRef saida As Variant) As Boolean
    On Error GoTo Invalido
    saida = Empty
    Select Case tipo
        Case "N": saida = Dinheiro(s)
        Case "D": saida = DataBR(s)
        Case "T": saida = s
        Case Else: Err.Raise 5, , "Tipo de regra desconhecido."
    End Select
    TentarConverter = True
    Exit Function
Invalido:
    saida = Empty
End Function

Private Sub VerificarTabelaZurich(ByVal texto As String, ByRef valores As Variant)
    Dim t As String, id As Variant, j As Long, suspeita As Boolean, dinheiroRX As String
    t = Recorte(Normalizar(texto), "Maquina de Vidros", "Clausulas")
    dinheiroRX = "[0-9][0-9.,]*,[0-9]{2}"
    suspeita = (Len(t) = 0)
    If RX("^[ ]+[0-9][0-9.,]*[ ]*$").Test(t) Then suspeita = True
    If Not RX("^[ ]*Vidro Traseiro[ ]+" & dinheiroRX & "[ ]*$").Test(t) Then suspeita = True
    If Not RX("^[ ]*Lanterna Convencional[ ]+" & dinheiroRX & "[ ]*$").Test(t) Then suspeita = True
    If Not suspeita Then Exit Sub
    For Each id In Array("parabrisa", "laterais", "traseiro", "farol", "farolled", "lanterna", "lanternaled", "retrovisor")
        j = LinhaCampo(CStr(id)) - 5
        valores(j, 1) = Empty
        valores(j, 2) = "Leitura ambigua"
        valores(j, 3) = "Tabela Zurich desalinhada ou incompleta. Nao associar valores soltos aos rotulos. Confira a imagem original ou tente OCR rasterizado."
    Next id
End Sub

Private Sub GuardarRevisao(ByVal s As String)
    Dim i As Long, quantidade As Long, anterior As Boolean
    anterior = Application.EnableEvents
    On Error GoTo Falha
    Application.EnableEvents = False
    Ws("Config").Range("D4:D" & Application.Max(4, Ws("Config").Cells(Ws("Config").Rows.Count, 4).End(xlUp).Row)).ClearContents
    quantidade = (Len(s) + 29999) \ 30000
    For i = 1 To quantidade
        Ws("Config").Cells(i + 4, 4).NumberFormat = "@"
        Ws("Config").Cells(i + 4, 4).Value2 = Mid$(s, (i - 1) * 30000 + 1, 30000)
    Next i
    Ws("Config").Range("D4").Value2 = "CP3|" & quantidade
    Application.EnableEvents = anterior
    Exit Sub
Falha:
    Dim mensagem As String
    mensagem = Err.Description
    On Error Resume Next
    Ws("Config").Range("D4").ClearContents
    Application.EnableEvents = anterior
    On Error GoTo 0
    Err.Raise vbObjectError + 130, , mensagem
End Sub

Private Function RevisaoConfere(ByVal s As String) As Boolean
    Dim partes As Variant, n As Long, i As Long, atual As String
    On Error GoTo Invalida
    partes = Split(CStr(Ws("Config").Range("D4").Value2), "|")
    If UBound(partes) <> 1 Then Exit Function
    If partes(0) <> "CP3" Then Exit Function
    n = CLng(partes(1))
    If n <> (Len(s) + 29999) \ 30000 Or n < 1 Then Exit Function
    For i = 1 To n
        atual = CStr(Ws("Config").Cells(i + 4, 4).Value2)
        If atual <> Mid$(s, (i - 1) * 30000 + 1, 30000) Then Exit Function
    Next i
    RevisaoConfere = True
Invalida:
End Function

Private Function AlturaTexto(ByVal cel As Range) As Double
    Dim caixa As Shape, mensagem As String
    On Error GoTo Falha
    Set caixa = Ws("Cotacao").Shapes.AddTextbox(1, Ws("Cotacao").Range("M1").Left, 0, cel.MergeArea.Width, 1000)
    With caixa.TextFrame2
        .WordWrap = True
        .MarginLeft = 3: .MarginRight = 3
        .MarginTop = 2: .MarginBottom = 2
        .TextRange.Text = CStr(cel.Value)
        .TextRange.Font.Name = cel.Font.Name
        .TextRange.Font.Size = cel.Font.Size
        AlturaTexto = .TextRange.BoundHeight + 6
    End With
    caixa.Delete
    Exit Function
Falha:
    mensagem = Err.Description
    On Error Resume Next
    If Not caixa Is Nothing Then caixa.Delete
    On Error GoTo 0
    Err.Raise vbObjectError + 131, , "Falha na medicao do texto: " & mensagem
End Function

Private Function ValidarLayout() As Boolean
    Dim r As Long, pagina1 As Double, pagina2 As Double, h As Double, minimo As Double
    For r = 1 To 8
        If Ws("Cotacao").Columns(r).Hidden Then
            MsgBox "Exiba as colunas A:H antes de revisar/exportar.", vbExclamation
            Exit Function
        End If
    Next r
    For r = 1 To 62
        If Ws("Cotacao").Rows(r).Hidden Then
            MsgBox "Exiba as linhas 1:62 antes de revisar/exportar.", vbExclamation
            Exit Function
        End If
        If (r >= 8 And r <= 28) Or (r >= 35 And r <= 59) Then
            h = AlturaTexto(Ws("Cotacao").Cells(r, 4))
            minimo = AlturaTexto(Ws("Cotacao").Cells(r, 1))
            If minimo > h Then h = minimo
            If h > 120 Then
                MsgBox "Texto extenso na linha " & r & " de Cotacao. Resuma o texto em Dados sem retirar condicoes essenciais e confira o PDF.", vbExclamation
                Exit Function
            End If
            If h < 19 Then h = 19
            Ws("Cotacao").Rows(r).RowHeight = h
        End If
        If r <= 32 Then
            pagina1 = pagina1 + Ws("Cotacao").Rows(r).RowHeight
        Else
            pagina2 = pagina2 + Ws("Cotacao").Rows(r).RowHeight
        End If
    Next r
    If pagina1 > 740 Or pagina2 > 740 Then
        MsgBox "O conteudo excede duas paginas legiveis. Reduza textos apos revisao e confira a visualizacao de impressao; exportacao bloqueada.", vbExclamation
        Exit Function
    End If
    ValidarLayout = True
End Function

Public Sub DiagnosticarFerramentas()
    Dim fs As Object, pasta As String, exe As String, naps As String, mensagem As String, arq As Variant
    On Error GoTo Falha
    If ocupado Then Exit Sub
    Set fs = CreateObject("Scripting.FileSystemObject")
    exe = CStr(Ws("Config").Range("B5").Value2)
    naps = CStr(Ws("Config").Range("B4").Value2)
    If Not fs.FileExists(exe) Then Err.Raise 5, , "pdftotext nao encontrado em Config!B5."
    If Not fs.FileExists(naps) Then Err.Raise 5, , "NAPS2 nao encontrado em Config!B4."
    pasta = fs.BuildPath(fs.GetSpecialFolder(2), "Credplus_Diagnostico_" & fs.GetTempName)
    fs.CreateFolder pasta
    Executar Q(exe) & " -v", 30, pasta & "\pdf.log"
    mensagem = "pdftotext: " & Left$(LerUTF8(pasta & "\pdf.log"), 600)
    Executar Q(naps) & " --help", 30, pasta & "\naps.log"
    mensagem = mensagem & vbCrLf & "NAPS2 responde a --help. A versao, OCR por, modo Melhor e rasterizacao multipagina ainda devem ser conferidos no teste com PDF."
    MsgBox mensagem, vbInformation
    GoTo Limpar
Falha:
    MsgBox "Diagnostico: " & Err.Description, vbExclamation
Limpar:
    On Error Resume Next
    If pasta <> "" Then
        For Each arq In Array("pdf.log", "naps.log")
            If fs.FileExists(pasta & "\" & arq) Then fs.DeleteFile pasta & "\" & arq, True
        Next arq
        RmDir pasta
    End If
End Sub

Public Function ConverterParaTeste(ByVal tipo As String, ByVal valor As String) As Variant
    Dim resultado As Variant
    If Not TentarConverter(tipo, valor, resultado) Then Err.Raise 5, , "Valor invalido."
    ConverterParaTeste = resultado
End Function

Private Sub GravarTextoCompleto(ByVal texto As String)
    Dim linhas As Variant, i As Long, pos As Long, r As Long, parte As String
    linhas = Split(Replace(texto, vbCr, ""), vbLf)
    r = 2
    For i = 0 To UBound(linhas)
        pos = 1
        Do
            If r > Ws("TextoPDF").Rows.Count Then Err.Raise 5, , "Texto excede a capacidade da aba de diagnostico."
            parte = Mid$(CStr(linhas(i)), pos, 30000)
            Ws("TextoPDF").Cells(r, 1).Value2 = i + 1
            Ws("TextoPDF").Cells(r, 2).NumberFormat = "@"
            Ws("TextoPDF").Cells(r, 2).Value2 = parte
            r = r + 1: pos = pos + 30000
        Loop While pos <= Len(CStr(linhas(i)))
    Next i
End Sub
