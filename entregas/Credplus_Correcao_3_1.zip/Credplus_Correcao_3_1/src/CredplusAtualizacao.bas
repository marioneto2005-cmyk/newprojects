Attribute VB_Name = "CredplusAtualizacao"
Option Explicit

Public Sub AplicarCorrecaoCredplus()
    Dim caminho As Variant, st As Object, texto As String, linhas As Variant, cols As Variant
    Dim regras As Variant, i As Long, j As Long, n As Long, oldEvents As Boolean, oldScreen As Boolean
    Dim w As Workbook, dados As Worksheet, config As Worksheet, cotacao As Worksheet, destino As Worksheet
    Dim anterior As Variant, formulas As Variant, assinatura As Variant, oldVersao As Variant
    Dim mudou As Boolean, mensagem As String, sh As Shape, candidatas As Long, logo As Shape
    Dim mapa As Object, dinheiro As String, r As Long, tipo As String, id As String, finalAnt As Long
    If Credplus.EmImportacao Then Exit Sub
    oldEvents = Application.EnableEvents: oldScreen = Application.ScreenUpdating
    On Error GoTo Falha
    Set w = ThisWorkbook
    Set dados = w.Worksheets("Dados"): Set config = w.Worksheets("Config")
    Set cotacao = w.Worksheets("Cotacao"): Set destino = w.Worksheets("Regras")
    caminho = Application.GetOpenFilename("Regras TSV (*.tsv),*.tsv", , "Selecione Regras.tsv desta entrega")
    If VarType(caminho) = vbBoolean Then Exit Sub
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2: st.Charset = "utf-8": st.Open
    st.LoadFromFile CStr(caminho): texto = st.ReadText: st.Close
    linhas = Split(Replace(texto, vbCr, ""), vbLf)
    Set mapa = CreateObject("Scripting.Dictionary")
    For i = 6 To 51
        id = CStr(dados.Cells(i, 6).Value2)
        If id = "" Or mapa.Exists(id) Then Err.Raise 5, , "Identificadores invalidos em Dados."
        mapa.Add id, i
    Next i
    For i = 1 To UBound(linhas)
        If Len(linhas(i)) > 0 Then n = n + 1
    Next i
    If n <> 237 Then Err.Raise 5, , "Arquivo de regras incompleto ou de outra versao. Esperadas 237 regras."
    ReDim regras(1 To n, 1 To 8)
    n = 0
    For i = 1 To UBound(linhas)
        If Len(linhas(i)) > 0 Then
            cols = Split(linhas(i), vbTab)
            If UBound(cols) <> 7 Then Err.Raise 5, , "Colunas invalidas na linha " & i + 1
            If Not mapa.Exists(CStr(cols(1))) Then Err.Raise 5, , "Campo desconhecido: " & cols(1)
            If Not IsNumeric(cols(5)) Then Err.Raise 5, , "Grupo invalido."
            If CLng(cols(5)) < 1 Then Err.Raise 5, , "Grupo invalido."
            Dim testeRX As Object
            Set testeRX = CreateObject("VBScript.RegExp")
            testeRX.Pattern = cols(4)
            testeRX.Test ""
            n = n + 1
            For j = 0 To 7: regras(n, j + 1) = cols(j): Next j
            regras(n, 6) = CLng(cols(5))
        End If
    Next i
    If MsgBox("Aplicar regras e formulas revisadas a ESTA COPIA? Dados, configuracoes locais e imagens serao preservados; a revisao anterior sera invalidada.", vbYesNo + vbQuestion) <> vbYes Then Exit Sub
    finalAnt = Application.Max(6, destino.Cells(destino.Rows.Count, 1).End(xlUp).Row)
    anterior = destino.Range("A6:H" & finalAnt).Value2
    formulas = cotacao.Range("A1:H62").Formula
    assinatura = config.Range("D4").Value2: oldVersao = config.Range("F4").Value2
    Application.EnableEvents = False: Application.ScreenUpdating = False
    mudou = True
    destino.Range("A6:H" & Application.Max(finalAnt, n + 5)).ClearContents
    destino.Range("A6:H" & n + 5).NumberFormat = "@"
    destino.Range("A6:H" & n + 5).Value2 = regras
    destino.Range("F6:F" & n + 5).NumberFormat = "0"
    destino.Range("A2").Value2 = "Credplus 3.1 - regras carregadas de Regras.tsv; revisao visual obrigatoria."
    For i = 6 To 51
        If i <= 26 Then r = i + 2 Else r = i + 8
        cotacao.Cells(r, 4).Formula = "=IF(LEN(Dados!B" & i & "&"""")=0,IF(Dados!C" & i & "=""Nao contratado"",""Nao contratado"",IF(Dados!C" & i & "=""Nao se aplica"",""Nao se aplica"",""Nao informado"")),Dados!B" & i & ")"
        tipo = CStr(dados.Cells(i, 7).Value2)
        cotacao.Cells(r, 4).NumberFormat = "General"
        If tipo = "N" Then cotacao.Cells(r, 4).NumberFormat = """R$"" #,##0.00"
        If tipo = "D" Then cotacao.Cells(r, 4).NumberFormat = "dd/mm/yyyy"
        cotacao.Cells(r, 4).WrapText = True
        cotacao.Cells(r, 1).WrapText = True
    Next i
    ' Casco may be a string (% FIPE) or a numeric determined value.
    cotacao.Range("D35").NumberFormat = """R$"" #,##0.00"
    config.Range("D4").ClearContents
    config.Range("F4").Value2 = "CREDPLUS-3.1"
    config.Range("B12").Value2 = "Atualizado - reimportar PDF e revisar"
    ' Preserve and identify the existing picture only after explicit visual confirmation.
    On Error Resume Next
    Set logo = cotacao.Shapes("LogoCredplus")
    On Error GoTo Falha
    If logo Is Nothing Then
        For Each sh In cotacao.Shapes
            If sh.Type = 13 Then candidatas = candidatas + 1: Set logo = sh
        Next sh
        If candidatas = 1 Then
            If MsgBox("Confirma que a unica imagem existente e a logomarca Sicoob Credplus?", vbYesNo + vbQuestion) = vbYes Then logo.Name = "LogoCredplus"
        End If
    End If
    Credplus.InicializarCredplus
    cotacao.Calculate
    Application.EnableEvents = oldEvents: Application.ScreenUpdating = oldScreen
    MsgBox "Regras e formulas aplicadas. Reimporte o PDF: valores antigos podem estar deslocados. Execute DiagnosticarFerramentas, depois os testes e a revisao. Salve como uma nova copia XLSB.", vbInformation
    Exit Sub
Falha:
    mensagem = Err.Description
    On Error Resume Next
    If mudou Then
        destino.Range("A6:H" & Application.Max(finalAnt, n + 5)).ClearContents
        destino.Range("A6:H" & finalAnt).Value2 = anterior
        cotacao.Range("A1:H62").Formula = formulas
        config.Range("F4").Value2 = oldVersao
        config.Range("D4").ClearContents
        config.Range("B12").Value2 = "Atualizacao incompleta - exportacao bloqueada"
    End If
    Application.EnableEvents = oldEvents: Application.ScreenUpdating = oldScreen
    MsgBox "Atualizacao interrompida: " & mensagem & ". Use a copia original se necessario; nao exporte antes de concluir os testes.", vbCritical
End Sub
