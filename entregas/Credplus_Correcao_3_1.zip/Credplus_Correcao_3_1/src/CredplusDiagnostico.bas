Attribute VB_Name = "CredplusDiagnostico"
Option Explicit

' Local diagnostic only. Does not write Dados, Config, Regras or the source PDF.
Private pastaSaida As String
Private resumo As String
Private prazoSegundos As Long
Private executando As Boolean

Public Sub ColetarDiagnosticoZurich()
    Dim escolhido As Variant, fs As Object, base As String, exe As String, naps As String
    Dim anteriorStatus As Variant, codigo As Long, erro As String, gerou As Boolean
    If executando Then Exit Sub
    On Error GoTo Falha
    anteriorStatus = Application.StatusBar
    escolhido = Application.GetOpenFilename("PDF (*.pdf),*.pdf", , "Selecione o PDF Zurich original para diagnostico local")
    If VarType(escolhido) = vbBoolean Then Exit Sub
    executando = True
    Set fs = CreateObject("Scripting.FileSystemObject")
    exe = CStr(ThisWorkbook.Worksheets("Config").Range("B5").Value2)
    naps = CStr(ThisWorkbook.Worksheets("Config").Range("B4").Value2)
    prazoSegundos = CLng(ThisWorkbook.Worksheets("Config").Range("B13").Value2)
    If prazoSegundos < 10 Or prazoSegundos > 3600 Then Err.Raise 5, , "Timeout deve estar entre 10 e 3600 segundos."
    If Not fs.FileExists(exe) Then Err.Raise 5, , "pdftotext nao encontrado em Config!B5."
    If Not fs.FileExists(naps) Then Err.Raise 5, , "NAPS2 nao encontrado em Config!B4."
    base = ThisWorkbook.Path
    If Not fs.FolderExists(base) Then Err.Raise 5, , "Salve esta copia do XLSB em uma pasta local primeiro."
    pastaSaida = fs.BuildPath(base, "Credplus_Diagnostico_" & Format$(Now, "yyyymmdd_hhnnss") & "_" & fs.GetTempName)
    fs.CreateFolder pastaSaida
    fs.CopyFile CStr(escolhido), pastaSaida & "\entrada.pdf", False
    gerou = True
    resumo = "Diagnostico local Credplus - nao modifica a cotacao" & vbCrLf
    resumo = resumo & "Data local: " & Format$(Now, "yyyy-mm-dd hh:nn:ss") & vbCrLf
    resumo = resumo & "Entrada copiada: " & CStr(escolhido) & vbCrLf
    resumo = resumo & "Etapa" & vbTab & "Codigo" & vbTab & "Segundos" & vbCrLf
    codigo = Rodar("01_versao_xpdf", Q(exe) & " -v")
    codigo = Rodar("02_versao_naps2", Q(naps) & " --version")
    codigo = Rodar("03_ajuda_naps2", Q(naps) & " --help")
    codigo = Rodar("04_original_layout", Q(exe) & " -layout -enc UTF-8 " & Q(pastaSaida & "\entrada.pdf") & " " & Q(pastaSaida & "\original_layout.txt"))

    codigo = Rodar("05_ocr_direto", Q(naps) & " -i " & Q(pastaSaida & "\entrada.pdf") & " -o " & Q(pastaSaida & "\ocr_direto.pdf") & " -n 0 --ocrlang por")
    If fs.FileExists(pastaSaida & "\ocr_direto.pdf") And codigo = 0 Then
        Extracoes exe, "ocr_direto.pdf", "direto"
    Else
        resumo = resumo & "OCR direto nao produziu PDF com sucesso." & vbCrLf
    End If

    codigo = Rodar("08_rasterizar_tiff", Q(naps) & " -i " & Q(pastaSaida & "\entrada.pdf") & " -o " & Q(pastaSaida & "\raster.tiff") & " -n 0 --disableocr")
    If fs.FileExists(pastaSaida & "\raster.tiff") And codigo = 0 Then
        codigo = Rodar("09_ocr_rasterizado", Q(naps) & " -i " & Q(pastaSaida & "\raster.tiff") & " -o " & Q(pastaSaida & "\ocr_rasterizado.pdf") & " -n 0 --ocrlang por")
        If fs.FileExists(pastaSaida & "\ocr_rasterizado.pdf") And codigo = 0 Then
            Extracoes exe, "ocr_rasterizado.pdf", "rasterizado"
        Else
            resumo = resumo & "OCR rasterizado nao produziu PDF com sucesso." & vbCrLf
        End If
    Else
        resumo = resumo & "Rasterizacao TIFF nao concluida; OCR forcado nao foi executado." & vbCrLf
    End If
    CompararExtracoes
    Gravar pastaSaida & "\RESUMO.txt", resumo
    Application.StatusBar = anteriorStatus
    executando = False
    MsgBox "Diagnostico concluido. A cotacao nao foi alterada." & vbCrLf & vbCrLf & "Pasta: " & pastaSaida & vbCrLf & vbCrLf & "Compacte essa pasta e envie o ZIP na conversa. Ela contem os PDFs e logs deste teste; nao publique em locais publicos.", vbInformation
    CreateObject("WScript.Shell").Run Q(Environ$("SystemRoot") & "\explorer.exe") & " " & Q(pastaSaida), 1, False
    Exit Sub
Falha:
    erro = Err.Description
    On Error Resume Next
    If gerou Then Gravar pastaSaida & "\RESUMO.txt", resumo & vbCrLf & "DIAGNOSTICO INCOMPLETO: " & erro
    Application.StatusBar = anteriorStatus
    executando = False
    MsgBox "Diagnostico interrompido: " & erro & vbCrLf & "A cotacao nao foi alterada. Artefatos ja gerados foram mantidos em: " & pastaSaida, vbExclamation
End Sub

Private Sub Extracoes(ByVal exe As String, ByVal pdf As String, ByVal prefixo As String)
    Dim codigo As Long
    codigo = Rodar(prefixo & "_layout", Q(exe) & " -layout -enc UTF-8 " & Q(pastaSaida & "\" & pdf) & " " & Q(pastaSaida & "\" & prefixo & "_layout.txt"))
    ' Xpdf table mode is probed, not presumed equivalent to Poppler.
    codigo = Rodar(prefixo & "_table", Q(exe) & " -table -enc UTF-8 " & Q(pastaSaida & "\" & pdf) & " " & Q(pastaSaida & "\" & prefixo & "_table.txt"))
    codigo = Rodar(prefixo & "_raw", Q(exe) & " -raw -enc UTF-8 " & Q(pastaSaida & "\" & pdf) & " " & Q(pastaSaida & "\" & prefixo & "_raw.txt"))
End Sub

Private Function Rodar(ByVal etapa As String, ByVal comando As String) As Long
    Dim shell As Object, processo As Object, inicio As Date, limite As Date, codigo As Long, mensagem As String, log As String
    On Error GoTo Falha
    Set shell = CreateObject("WScript.Shell")
    log = pastaSaida & "\" & etapa & ".log"
    Application.StatusBar = "Credplus diagnostico: " & etapa & " (aguarde; timeout por processo: " & prazoSegundos & " s)"
    If InStr(comando & log, "%") > 0 Or InStr(comando & log, "!") > 0 Then Err.Raise 5, , "Caminhos contendo % ou ! nao sao suportados pelo executor."
    inicio = Now: limite = DateAdd("s", prazoSegundos, inicio)
    Set processo = shell.Exec(Q(Environ$("ComSpec")) & " /d /s /c " & Chr$(34) & comando & " 1>" & Q(log) & " 2>&1" & Chr$(34))
    Do While processo.Status = 0
        DoEvents
        If Now >= limite Then
            shell.Run Q(Environ$("SystemRoot") & "\System32\taskkill.exe") & " /PID " & processo.ProcessID & " /T /F", 0, True
            resumo = resumo & etapa & vbTab & "TIMEOUT" & vbTab & DateDiff("s", inicio, Now) & vbCrLf
            Rodar = -2
            Gravar pastaSaida & "\RESUMO.txt", resumo
            Exit Function
        End If
    Loop
    codigo = processo.ExitCode
    resumo = resumo & etapa & vbTab & codigo & vbTab & DateDiff("s", inicio, Now) & vbCrLf
    Rodar = codigo
    Gravar pastaSaida & "\RESUMO.txt", resumo
    Exit Function
Falha:
    mensagem = Err.Description
    resumo = resumo & etapa & vbTab & "ERRO" & vbTab & mensagem & vbCrLf
    Rodar = -1
End Function

Private Sub CompararExtracoes()
    Dim fs As Object, arq As Variant, nome As String, texto As String, dados As Variant
    Dim saida As String, i As Long, campo As String, conteudo As String, erro As String
    Set fs = CreateObject("Scripting.FileSystemObject")
    saida = "arquivo" & vbTab & "linha_Dados" & vbTab & "campo" & vbTab & "valor" & vbTab & "situacao" & vbCrLf
    For Each arq In Array("original_layout.txt", "direto_layout.txt", "direto_table.txt", "rasterizado_layout.txt", "rasterizado_table.txt")
        nome = pastaSaida & "\" & CStr(arq)
        If fs.FileExists(nome) Then
            texto = Ler(nome)
            resumo = resumo & CStr(arq) & " - caracteres: " & Len(texto) & vbCrLf
            On Error GoTo FalhaParser
            dados = Credplus.ExtrairTextoParaTeste(texto, "Zurich", 1)
            For i = 1 To 46
                campo = CStr(ThisWorkbook.Worksheets("Dados").Cells(i + 5, 6).Value2)
                conteudo = Replace(Replace(Replace(CStr(dados(i, 1)), vbTab, " "), vbCr, " "), vbLf, " ")
                saida = saida & CStr(arq) & vbTab & i + 5 & vbTab & campo & vbTab & conteudo & vbTab & CStr(dados(i, 2)) & vbCrLf
            Next i
        Else
            resumo = resumo & CStr(arq) & " - nao produzido" & vbCrLf
        End If
Proximo:
        On Error GoTo 0
    Next arq
    Gravar pastaSaida & "\COMPARACAO.tsv", saida
    Exit Sub
FalhaParser:
    erro = Err.Description
    resumo = resumo & CStr(arq) & " - erro ao aplicar regras: " & erro & vbCrLf
    Resume Proximo
End Sub

Private Function Q(ByVal s As String) As String
    If InStr(s, Chr$(34)) > 0 Or InStr(s, vbCr) > 0 Or InStr(s, vbLf) > 0 Then Err.Raise 5, , "Caminho invalido."
    Q = Chr$(34) & s & Chr$(34)
End Function

Private Function Ler(ByVal caminho As String) As String
    Dim st As Object
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2: st.Charset = "utf-8": st.Open
    st.LoadFromFile caminho: Ler = st.ReadText: st.Close
End Function

Private Sub Gravar(ByVal caminho As String, ByVal texto As String)
    Dim st As Object
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2: st.Charset = "utf-8": st.Open
    st.WriteText texto: st.SaveToFile caminho, 2: st.Close
End Sub
