Attribute VB_Name = "TestesCredplus"
Option Explicit
Private relatorio As String
Private aprovados As Long
Private falhos As Long

Public Sub TestarCredplus()
    Dim dialogo As Object, pasta As String, i As Long, dados As Variant, texto As String, st As Object
    Dim numero As Double, invalido As Variant, falhou As Boolean, total As Double, seg As String, arquivo As String, oferta As Long
    Dim fs As Object, destino As String
    On Error GoTo SetupFalhou
    Set dialogo = Application.FileDialog(4)
    dialogo.Title = "Selecione tests\fixtures desta entrega"
    If dialogo.Show <> -1 Then Exit Sub
    pasta = dialogo.SelectedItems(1)
    aprovados = 0: falhos = 0: relatorio = "teste;resultado;detalhe" & vbCrLf
    For i = 1 To 15
        On Error GoTo CasoFalhou
        Select Case i
            Case 1 To 5
                seg = "Allianz": arquivo = "alliaz-auto-layout.txt": oferta = i
            Case 6 To 7
                seg = "HDI": arquivo = "hdi-AUTO.txt": oferta = i - 5
            Case 8 To 9
                seg = "Tokio Marine": arquivo = "tokio-auto-layout.txt": oferta = i - 7
            Case 10
                seg = "Yelum": arquivo = "yellum-auto-layout.txt": oferta = 1
            Case 11
                seg = "Zurich": arquivo = "zurich-auto-layout.txt": oferta = 1
            Case 12
                seg = "Zurich": arquivo = "zurich-planilha.txt": oferta = 1
        End Select
        If i <= 12 Then
            texto = Ler(pasta & "\" & arquivo)
            dados = Credplus.ExtrairTextoParaTeste(texto, seg, oferta)
            Select Case i
                Case 1 To 5
                    ' Val is deliberate for dot-decimal fixture constants, independent of locale.
                    total = Val(Split("2030.76|2068.72|2121.46|2202.64|2383.99", "|")(i - 1))
                    Igual Valor(dados, "total"), total, "total Allianz"
                    Igual Valor(dados, "franquia"), 3213.2, "franquia Allianz"
                    Igual Valor(dados, "dm"), Val(Split("100000|150000|200000|400000|1000000", "|")(i - 1)), "LMI Allianz"
                Case 6 To 7
                    If oferta = 1 Then total = 1813.15 Else total = 1736.78
                    Igual Valor(dados, "total"), total, "total HDI"
                    Igual Valor(dados, "franquia"), 3955.92, "franquia HDI"
                    Igual Valor(dados, "fim"), DateSerial(2027, 10, 24), "fim vigencia HDI"
                Case 8 To 9
                    If oferta = 1 Then total = 1825.59 Else total = 1716.36
                    Igual Valor(dados, "total"), total, "preco normal Tokio"
                    Igual Valor(dados, "franquia"), 2749, "franquia Tokio"
                    Igual Valor(dados, "parabrisa"), 345, "parabrisa Tokio"
                Case 10
                    Igual Valor(dados, "total"), 1583.39, "total Yelum"
                    Igual Valor(dados, "appm"), 20000, "APP morte Yelum"
                    Igual Valor(dados, "appi"), 20000, "APP invalidez Yelum"
                    Exigir IsEmpty(Valor(dados, "cep")), "CEP incompleto nao pode ser completado"
                Case 11
                    Igual Valor(dados, "total"), 2295.71, "total Zurich"
                    Igual Valor(dados, "parabrisa"), 285, "parabrisa Zurich"
                    Igual Valor(dados, "traseiro"), 390, "traseiro Zurich"
                    Exigir IsEmpty(Valor(dados, "appm")), "APP conjunto nao e morte"
                Case 12
                    Exigir IsEmpty(Valor(dados, "parabrisa")), "Tabela antiga desalinhada deve ser bloqueada"
                    Exigir Len(CStr(Valor(dados, "condutor"))) > 0, "Condutor deve ser recuperado"
            End Select
        ElseIf i = 13 Then
            Igual Credplus.ConverterParaTeste("N", "1.234,56"), 1234.56, "conversao independente de idioma"
            Igual Credplus.ConverterParaTeste("N", "0,00"), 0, "zero nao e vazio"
        ElseIf i = 14 Then
            On Error Resume Next
            Err.Clear
            invalido = Credplus.ConverterParaTeste("N", "1.234,5X")
            falhou = (Err.Number <> 0)
            Err.Clear
            On Error GoTo CasoFalhou
            Exigir falhou, "Dinheiro invalido deve falhar"
        ElseIf i = 15 Then
            On Error Resume Next
            Err.Clear
            invalido = Credplus.ConverterParaTeste("D", "31/02/2026")
            falhou = (Err.Number <> 0)
            Err.Clear
            On Error GoTo CasoFalhou
            Exigir falhou, "Data invalida deve falhar"
        End If
        aprovados = aprovados + 1
        relatorio = relatorio & i & ";PASS;caso executado no Excel" & vbCrLf
        GoTo Proximo
CasoFalhou:
        falhos = falhos + 1
        relatorio = relatorio & i & ";FAIL;" & Replace(Replace(Err.Description, ";", ","), vbCrLf, " ") & vbCrLf
        Resume Proximo
Proximo:
        On Error GoTo SetupFalhou
    Next i
    Set fs = CreateObject("Scripting.FileSystemObject")
    destino = fs.BuildPath(pasta, "resultados_excel_" & Format$(Now, "yyyymmdd_hhnnss") & ".csv")
    If fs.FileExists(destino) Then Err.Raise 5, , "Resultado ja existe; aguarde um segundo e execute novamente."
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2: st.Charset = "utf-8": st.Open
    st.WriteText relatorio: st.SaveToFile destino, 1: st.Close
    MsgBox "Testes executados no Excel: " & aprovados & " aprovados; " & falhos & " falhos. Resultado: " & destino & vbCrLf & "Ainda faltam os testes de OCR/processos, cancelamento, eventos, salvamento e PDF descritos em VALIDACAO.", vbInformation
    Exit Sub
SetupFalhou:
    MsgBox "Testes nao concluidos: " & Err.Description & ". Nao marque a suite como aprovada.", vbExclamation
End Sub

Private Function Ler(ByVal caminho As String) As String
    Dim st As Object
    Set st = CreateObject("ADODB.Stream")
    st.Type = 2: st.Charset = "utf-8": st.Open: st.LoadFromFile caminho
    Ler = st.ReadText: st.Close
End Function

Private Function Valor(ByRef dados As Variant, ByVal id As String) As Variant
    Dim i As Long
    For i = 6 To 51
        If ThisWorkbook.Worksheets("Dados").Cells(i, 6).Value2 = id Then
            Valor = dados(i - 5, 1): Exit Function
        End If
    Next i
    Err.Raise 5, , "Campo nao encontrado: " & id
End Function

Private Sub Igual(ByVal atual As Variant, ByVal esperado As Variant, ByVal nome As String)
    If IsEmpty(atual) Then Err.Raise 5, , nome & ": vazio inesperado"
    If IsNumeric(atual) And IsNumeric(esperado) Then
        If Abs(CDbl(atual) - CDbl(esperado)) > 0.005 Then Err.Raise 5, , nome & ": valor divergente"
    Else
        If CStr(atual) <> CStr(esperado) Then Err.Raise 5, , nome & ": valor divergente"
    End If
End Sub

Private Sub Exigir(ByVal condicao As Boolean, ByVal mensagem As String)
    If Not condicao Then Err.Raise 5, , mensagem
End Sub
