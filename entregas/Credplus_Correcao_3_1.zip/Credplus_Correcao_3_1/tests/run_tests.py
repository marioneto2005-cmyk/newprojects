"""Executar com Python 3.10+; usa somente a biblioteca padrao."""
from pathlib import Path
import unittest,csv,io,json
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[1]
class Results(unittest.TextTestResult):
 def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.rows=[]
 def addSuccess(self,test):super().addSuccess(test);self.rows.append((test.id(),'PASS','Python / inspecao estatica'))
 def addFailure(self,test,err):super().addFailure(test,err);self.rows.append((test.id(),'FAIL',self._exc_info_to_string(err,test)))
 def addError(self,test,err):super().addError(test,err);self.rows.append((test.id(),'ERROR',self._exc_info_to_string(err,test)))
 def addSkip(self,test,reason):super().addSkip(test,reason);self.rows.append((test.id(),'SKIP',reason))
if __name__=='__main__':
 out=ROOT/'docs';out.mkdir(exist_ok=True)
 suite=unittest.defaultTestLoader.discover(str(ROOT/'tests'),pattern='test_*.py')
 buf=io.StringIO();r=unittest.TextTestRunner(stream=buf,verbosity=2,resultclass=Results).run(suite)
 (out/'testes_python.log').write_text(buf.getvalue(),encoding='utf-8')
 with (out/'resultados_testes.csv').open('w',encoding='utf-8-sig',newline='') as f:
  writer=csv.writer(f);writer.writerow(['teste','resultado','escopo']);writer.writerows(r.rows)
 (out/'resultado_execucao.json').write_text(json.dumps({'executado_em_utc':datetime.now(timezone.utc).isoformat(),'tests_run':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'excel_compilado':False,'macros_executadas':False,'naps2_windows_executado':False,'pdf_excel_conferido':False},indent=2))
 print(buf.getvalue());raise SystemExit(0 if r.wasSuccessful() else 1)
