"""Regras em Python e inspecao estatica: nao substituem compilar/executar no Excel."""
from pathlib import Path
import unittest,json,re,datetime,zipfile
from engine import extract,valid_id,rx,MONEY,column,norm
ROOT=Path(__file__).resolve().parents[1]
FIX=ROOT/'tests/fixtures'
RULES=json.loads((ROOT/'src/regras.json').read_text())
ORIGINAL=json.loads((FIX/'original-rules.json').read_text())
CASES=[('Allianz','alliaz-auto-layout',5),('HDI','hdi-AUTO',2),('Tokio Marine','tokio-auto-layout',2),('Yelum','yellum-auto-layout',1),('Zurich','zurich-auto-layout',1)]
def read(name):return (FIX/(name+'.txt')).read_text(encoding='utf-8')
def run(seg,file,n=1):return extract(read(file),seg,n,RULES,True)
def val(d,key):return d.get(key,{}).get('value')
class RealDocumentRegression(unittest.TestCase):
 def test_original_zurich_problem_reproduced(self):
  d=extract(read('zurich-planilha'),'Zurich',1,ORIGINAL)
  self.assertIsNone(val(d,'condutor'))
  self.assertEqual(val(d,'parabrisa'),615.0)
  self.assertEqual(val(d,'laterais'),250.0)
  self.assertEqual(val(d,'farol'),390.0)
  self.assertIsNone(val(d,'traseiro'))
 def test_zurich_stored_text_blocks_shifted_table(self):
  d=run('Zurich','zurich-planilha')
  self.assertTrue(val(d,'condutor'))
  for k in ['parabrisa','laterais','traseiro','farol','farolled','lanterna','lanternaled','retrovisor']:
   with self.subTest(field=k):
    self.assertIsNone(val(d,k));self.assertEqual(d[k]['state'],'Leitura ambigua')
 def test_zurich_fresh_ocr_values_match_image(self):
  d=run('Zurich','zurich-auto-layout')
  for k,v in dict(total=2295.71,franquia=5942.25,dm=100000.,dc=100000.,morais=10000.,appg=20000.,parabrisa=285.,laterais=120.,traseiro=390.,farol=250.,farolled=1405.,lanterna=230.,lanternaled=310.,retrovisor=385.).items():
   with self.subTest(field=k):self.assertEqual(val(d,k),v)
  self.assertIsNone(val(d,'appm'));self.assertIsNone(val(d,'appi'))
  self.assertEqual(val(d,'tipofranquia'),'A')
 def test_zurich_chassis_not_guessed(self):
  old=run('Zurich','zurich-planilha');self.assertIsNone(val(old,'chassi'))
  new=run('Zurich','zurich-auto-layout');self.assertEqual(val(new,'chassi'),'9BD281BMTSYG05430')
 def test_zurich_dates(self):
  d=run('Zurich','zurich-auto-layout');self.assertEqual(val(d,'validade'),'2026-11-04')
  self.assertEqual(val(d,'inicio'),'2026-10-27');self.assertEqual(val(d,'fim'),'2027-10-27')
 def test_allianz_all_five_offers(self):
  for i,(total,lmi) in enumerate(zip([2030.76,2068.72,2121.46,2202.64,2383.99],[100000,150000,200000,400000,1000000]),1):
   with self.subTest(offer=i):
    d=run('Allianz','alliaz-auto-layout',i)
    self.assertEqual(val(d,'total'),total);self.assertEqual(val(d,'dm'),lmi);self.assertEqual(val(d,'dc'),lmi)
    self.assertEqual(val(d,'franquia'),3213.2);self.assertEqual(val(d,'tipofranquia'),'50% da Normal')
    self.assertEqual(val(d,'appm'),val(d,'appi'))
 def test_allianz_payment_divergence(self):
  d=run('Allianz','alliaz-auto-layout',5)
  self.assertEqual(d['total']['state'],'Revisar divergencia')
  self.assertEqual(val(d,'total'),2383.99)
 def test_allianz_cpf_has_own_evidence(self):
  d=run('Allianz','alliaz-auto-layout')
  self.assertEqual(val(d,'cpf'),'112.470.116-82');self.assertIn('CPF/CNPJ:',d['cpf']['evidence'])
  t=read('alliaz-auto-layout').replace('CPF/CNPJ: 112.470.116-82','CPF/CNPJ:')
  d=extract(t,'Allianz',1,RULES,True)
  self.assertIsNone(val(d,'cpf'));self.assertEqual(val(d,'cpfcond'),'112.470.116-82')
 def test_tokio_two_products(self):
  for i,total in enumerate([1825.59,1716.36],1):
   with self.subTest(offer=i):
    d=run('Tokio Marine','tokio-auto-layout',i)
    self.assertEqual(val(d,'total'),total);self.assertEqual(val(d,'franquia'),2749.)
    for k in ['dm','dc']:self.assertEqual(val(d,k),200000.)
    for k in ['appm','appi']:self.assertEqual(val(d,k),10000.)
    self.assertEqual(val(d,'parabrisa'),345.);self.assertEqual(val(d,'traseiro'),295.);self.assertEqual(val(d,'laterais'),140.)
    self.assertEqual(val(d,'cpf'),'090.122.606-80');self.assertEqual(val(d,'condutor'),'Proprio Segurado')
    self.assertNotIn('R$',val(d,'modelo'))
 def test_tokio_office_distinction(self):
  a=run('Tokio Marine','tokio-auto-layout',1);b=run('Tokio Marine','tokio-auto-layout',2)
  self.assertEqual(val(a,'observacoes'),'Livre Escolha');self.assertEqual(val(b,'observacoes'),'Rede Referenciada')
 def test_tokio_damaged_coverage_label_needs_manual_review(self):
  # Fresh OCR reads RCF-Y on this line. Do not silently assume another coverage.
  d=run('Tokio Marine','tokio-auto-layout');self.assertIsNone(val(d,'morais'))
 def test_hdi_two_modalities(self):
  for i,total in [(1,1813.15),(2,1736.78)]:
   with self.subTest(offer=i):
    d=run('HDI','hdi-AUTO',i)
    self.assertEqual(val(d,'total'),total);self.assertEqual(val(d,'franquia'),3955.92)
    self.assertEqual(val(d,'inicio'),'2026-10-24');self.assertEqual(val(d,'fim'),'2027-10-24')
    self.assertEqual(val(d,'validade'),'2026-10-24')
    self.assertEqual(val(d,'casco'),'100,00% FIPE' if i==1 else 60750.)
    for k,v in dict(parabrisa=350.,laterais=145.,traseiro=330.,farol=565.,lanterna=270.,auxiliar=160.).items():self.assertEqual(val(d,k),v)
 def test_yelum_multiline_app_and_incomplete_cep(self):
  d=run('Yelum','yellum-auto-layout')
  for k,v in dict(total=1583.39,franquia=3395.,dm=200000.,dc=200000.,morais=30000.,appm=20000.,appi=20000.).items():self.assertEqual(val(d,k),v)
  self.assertIsNone(val(d,'cep'));self.assertEqual(d['cep']['state'],'Leitura ambigua')
  self.assertNotIn('km',val(d,'assistencia').lower())
  self.assertEqual(val(d,'validade'),'2026-10-24')
  self.assertEqual(val(d,'inicio'),'2026-10-27');self.assertEqual(val(d,'fim'),'2027-10-27')
 def test_young_driver_age_preserved(self):
  self.assertIn('menos de 25 anos',val(run('Zurich','zurich-auto-layout'),'jovens'))
  self.assertIn('18 a 24 anos',val(run('Yelum','yellum-auto-layout'),'jovens'))
  self.assertIn('18 a 25 anos',val(run('Tokio Marine','tokio-auto-layout'),'jovens'))
class DamagedInputRegression(unittest.TestCase):
 def test_missing_limit_never_becomes_premium_all_offers(self):
  t=read('alliaz-auto-layout')
  for i in range(1,6):
   c=column(norm(t),i)
   # Remove only LMI, keep premium and positions within selected column.
   c=re.sub(r'(RCF\*\* - Danos Materiais +)([0-9.,]+)',lambda m:m[1]+' '*len(m[2]),c)
   # Full-text mutation must preserve geometry before column slicing.
   row=next(l for l in t.splitlines() if 'RCF** - Danos Materiais' in l)
   h=[l for l in t.splitlines() if 'RCF** - Danos Materiais' in l][0 if i<=3 else 1]
   matches=list(re.finditer(MONEY,h));idx=(i-1 if i<=3 else i-4)*2
   m=matches[idx]; altered=h[:m.start()]+' '*len(m[0])+h[m.end():]
   mutated=t.replace(h,altered,1)
   d=extract(mutated,'Allianz',i,RULES,True)
   self.assertIsNone(val(d,'dm'),f'offer {i} captured premium')
 def test_truncated_and_invalid_money_rejected(self):
  t=read('hdi-AUTO')
  for bad in ['200.000,0','200.000,00X','200.000,000','20O.000,00']:
   row=next(l for l in t.splitlines() if l.startswith('RCF-V DANOS MATERIAIS'))
   changed=row.replace('200.000,00',bad,1)
   d=extract(t.replace(row,changed),'HDI',1,RULES,True)
   self.assertIsNone(val(d,'dm'),bad)
 def test_different_quotes_produce_ambiguity(self):
  t=read('hdi-AUTO');d=extract(t+t.replace('VANDA APARECIDA RODRIGUES','OUTRA PESSOA'),'HDI',1,RULES,True)
  self.assertIsNone(val(d,'nome'));self.assertEqual(d['nome']['state'],'Leitura ambigua')
 def test_sequential_extractions_are_independent(self):
  a=run('HDI','hdi-AUTO');b=extract('Documento sem campos','HDI',1,RULES,True)
  self.assertEqual(val(a,'total'),1813.15);self.assertIsNone(val(b,'total'));self.assertIsNone(val(b,'cpf'))
 def test_zero_distinct_from_missing(self):
  t=read('hdi-AUTO');row=next(l for l in t.splitlines() if l.startswith('TOTAL À VISTA'))
  zero=re.sub(MONEY,'0,00',row,count=1)
  d=extract(t.replace(row,zero),'HDI',1,RULES,True);self.assertEqual(val(d,'total'),0.)
  d=extract(t.replace(row,''),'HDI',1,RULES,True);self.assertIsNone(val(d,'total'))
 def test_invalid_identifiers_never_repaired(self):
  self.assertFalse(valid_id('cep','35595'));self.assertFalse(valid_id('chassi','9B3D281BMTSYGO05430'))
  self.assertFalse(valid_id('cpf','00000000000'));self.assertFalse(valid_id('cpf','090.122.606-81'))
 def test_date_normalization_rejected(self):
  t=read('hdi-AUTO').replace('COTAÇÃO VÁLIDA ATÉ 24/10/2026','COTAÇÃO VÁLIDA ATÉ 31/02/2026')
  d=extract(t,'HDI',1,RULES,True);self.assertIsNone(val(d,'validade'))
class StaticComponents(unittest.TestCase):
 def test_rule_groups_and_vbscript_syntax_subset(self):
  self.assertEqual(len(RULES),237)
  for r in RULES:
   with self.subTest(insurer=r[0],field=r[1],offer=r[7]):
    compiled=rx(r[4]);self.assertGreaterEqual(int(r[5]),1);self.assertLessEqual(int(r[5]),compiled.groups)
    self.assertNotIn('(?<',r[4]);self.assertNotIn('(?P',r[4])
 def test_tsv_matches_executed_rules(self):
  lines=(ROOT/'src/Regras.tsv').read_text().splitlines()[1:]
  self.assertEqual(len(lines),len(RULES))
  for line,rule in zip(lines,RULES):self.assertEqual(line.split('\t'),list(map(str,rule)))
 def test_vba_procedure_structure_and_unique_names(self):
  for p in (ROOT/'src').glob('*'):
   if p.suffix.lower() not in ('.bas','.cls'):continue
   s=p.read_text(encoding='utf-8')
   defs=re.findall(r'^(?:Public|Private) (Sub|Function) (\w+)\b',s,re.M)
   ends=re.findall(r'^End (Sub|Function)\b',s,re.M)
   self.assertEqual([d[0] for d in defs],ends,p.name)
   self.assertEqual(len(defs),len({n.lower() for _,n in defs}),p.name)
   self.assertIn('Option Explicit',s)
   self.assertLess(max(map(len,s.splitlines())),1023,p.name)
 def test_no_active_workbook_dependencies_or_api_declares(self):
  s=(ROOT/'src/Credplus.bas').read_text()
  self.assertNotRegex(s,r'\b(?:ActiveWorkbook|ActiveSheet|Declare)\b')
  self.assertNotIn('InvalidarRevisao:',s)
 def test_export_is_worksheet_scoped_and_reviews_exact_chunks(self):
  s=(ROOT/'src/Credplus.bas').read_text()
  self.assertIn('Ws("Cotacao").ExportAsFixedFormat',s)
  self.assertNotIn('ThisWorkbook.ExportAsFixedFormat',s)
  self.assertIn('.PrintArea = "$A$1:$H$62"',s)
  self.assertIn('FileFormat:=50',s);self.assertIn('RevisaoConfere(AssinaturaAtual())',s)
  self.assertIn('30000',s);self.assertNotIn('Evidencias muito longas',s)
 def test_xpdf_version_exit99_exception_is_diagnostic_only(self):
  s=(ROOT/'src/Credplus.bas').read_text()
  self.assertIn('Optional ByVal consultaVersao As Boolean = False',s)
  self.assertIn('If consultaVersao Then',s)
  self.assertIn('If proc.ExitCode = 0 Or proc.ExitCode = 99 Then',s)
  self.assertIn('^pdftotext version [0-9]+',s)
  enabled=[line.strip() for line in s.splitlines() if line.strip().startswith('Executar ') and line.rstrip().endswith(', True')]
  self.assertEqual(enabled,['Executar Q(exe) & " -v", 30, pasta & "\\pdf.log", True'])
 def test_process_timeout_cleans_only_owned_files(self):
  s=(ROOT/'src/Credplus.bas').read_text()
  self.assertIn(' /T /F',s);self.assertIn('1>',s);self.assertIn('2>&1',s)
  self.assertIn('raster.tiff',s);self.assertIn('--disableocr',s)
  self.assertNotRegex(s,r'DeleteFolder|Kill "\*|DeleteFile.*\*')
if __name__=='__main__':unittest.main(verbosity=2)
